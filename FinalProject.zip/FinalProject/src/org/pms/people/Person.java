package org.pms.people;

public class Person {
	
	//Fields
	protected String DOB;
	protected String name;
	protected String address;
	protected char gender;
	protected String phoneNo;
	protected String emailID;
	protected int age;
	protected String username;
	protected String password;
	
	
	//Constructor
	public Person() {
		this.DOB = null;
		this.name = null;
		this.address = null;
		this.gender = '\0';
		this.phoneNo = null;
		this.emailID = null;
		this.age = 0;
		
	}
	
	//Getters and Setters
	
	public String getDOB() {
		return this.DOB;
	}
	public void setDOB(String DOB) {
		this.DOB = DOB;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	
	//checking validity of password
	public boolean checkPassword(String username, String password, Person person) {
		if(this.password.equals(password) && this.username.equals(username)) {
			System.out.println("\nWELCOME!!!");
			return true;
		}
		else {
			System.out.println("\nERROR: Wrong Password or User Name");
		}
		return false;
	}
	//Methods
	

	
	public void menu() {
		
	}

}
