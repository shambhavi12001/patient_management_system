package org.pms.people;

import java.util.Objects;

//import org.pms.datafiles.ProcedureForm;
import org.pms.hospital.*;

public class InPatient extends Patient{

	//Fields
	private Doctor doctor;
	private Nurse nurse;
	private Room room;
	private ProcedureForm procedureForm;
	private boolean discharged;

	//Constructor
	public InPatient() {
		this.nurse = null;
		this.doctor = null;
		this.setRoom(null);
		this.setProcedureForm(null);
		this.discharged = false;
	}
	
	//Getters and Setters
	public Nurse getNurse() {
		return this.nurse;
	}
	
	public void setNurse(Nurse n) {
		this.nurse = n;
		n.addInPatient(this);
	}
	
	public Doctor getDoctor() {
		return this.doctor;
	}
	public void setDoctor(Doctor n) {
		this.doctor = n;
	}
	
	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		if(room != null) {
			if(Objects.isNull(room.getPatient())) {
				this.room = room;
			}
		}
	}

	public ProcedureForm getProcedureForm() {
		return procedureForm;
	}

	public void setProcedureForm(ProcedureForm procedureForm) {
		this.procedureForm = procedureForm;
	}

	public boolean isDischarged() {
		return discharged;
	}

	public void setDischarged(boolean discharged) {
		this.discharged = discharged;
	}
	
}
