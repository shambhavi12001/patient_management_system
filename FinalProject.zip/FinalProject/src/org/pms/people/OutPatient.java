package org.pms.people;

//import org.pms.datafiles.Schedule;
//import org.pms.datafiles.ScheduleForm;
import org.pms.hospital.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
public class OutPatient extends Patient {
	
	//Fields
	//private Schedule schedule;
	//private ScheduleForm scheduleForm;
	private Appointment appointment;

	Scanner sc = new Scanner(System.in);
	
	//Constructor
	public OutPatient() {
		//this.schedule = null;
		//this.setScheduleForm(null);
		appointment = null;
		bill = null;
	}
	/*
	//Getters and Setters
	public Schedule getSchedule() {
		return this.schedule;
	}
	public void setSchedule(Schedule sched) {
		this.schedule = sched;
	}

	public ScheduleForm getScheduleForm() {
		return scheduleForm;
	}

	public void addScheduleForm(ScheduleForm scheduleForm) {
		this.scheduleForm = scheduleForm;
	}
	*/

	public void setBill(Billing bill) {
		this.bill = bill;
	}
	
	
	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

	//Booking an appointment form
	public void bookAppointment(Doctor doctor, int date, int time) {
		if(this.appointment != null) {
			System.out.println("You already have an appointment booked: \n" + this.appointment.getAppointment()
					+ "\nChoose another option...");
			//wrongChoice = true;
		}
		else {
			
			this.appointment = new Appointment();
			this.appointment.setAppointment((doctor.getAvailableDates().get(date)) + " " + doctor.getAvailableSlots().get(date).get(time));
			this.appointment.setDoctor(doctor);
			this.appointment.setPatient(this);
			
			doctor.addToSchedule(this.appointment);
			doctor.getPatientList().add(this);
			
			doctorFee();
			System.out.println("Appointment Confirmation -> \nDoctor: " + doctor.getName() + "\nAppointment: " + this.appointment.getAppointment() + "\n");
			
			if(doctor.getAvailableSlots().get(date).size() == 1) {
				doctor.getAvailableDates().remove(date);
				doctor.getAvailableSlots().remove(date);
			}
			else {
				doctor.getAvailableSlots().get(date).remove(time);
			}
			/*
			for(String slot: doctor.getSchedule()) {
				System.out.println(slot);
			}
			*/
		}
		
	}
	
	public void viewAppointment() {
		if(appointment != null) {
			System.out.println("Doctor: " + this.appointment.getDoctor().getName() + "\nAppointment: " + this.appointment.getAppointment() + "\n");
			
		}
		else {
			System.out.println("You do not have any appointments");
		}
	}
	/*
	public void rescheduleAppointment() {
		cancelAppointment();
		System.out.println("\nBook another appoitnment: ");
		bookAppointment();
	}
	*/
	
	//Canceling appointment steps
	public void cancelAppointment() {
		if(!Objects.isNull(this.appointment)) {
			checkCharges();
			for(Appointment appt: this.appointment.getDoctor().getSchedule()) {
				if(this.appointment.getAppointment().equals(appt.getAppointment())) {
					this.appointment.getDoctor().getSchedule().remove(appt);
					break;
				}
			}
			this.appointment.getDoctor().generateAvailability();
			this.appointment.getDoctor().getPatientList().remove(this);
			this.appointment = null;
			System.out.println("\nYour appointment has been successfully cancelled!");
			
		}
		else {
			System.out.println("\nERROR: You do not have an appointment");
		}
		
	}
	
	//Setting doctor's fee
	public void doctorFee() {
		
		this.bill.getTreatmentList().add("Doctor's Fee");
		this.bill.getCharge().add(100.0);
		
	}
	
	//Setting up final charge for patient
	public void checkCharges() {
		long time_diff = this.appointment.getOriginalDate(this.appointment.getAppointment()).getTime() - 
				this.appointment.getCurrTime().getTime();
		System.out.println((time_diff / (1000.0 * 60.0 * 60)));
			
		for(int i = this.getBilling().getTreatmentList().size() - 1; i >= 0; --i) {
			if(this.getBilling().getTreatmentList().get(i).equals("Doctor's Fee")){
				this.getBilling().getTreatmentList().remove(i);					
				this.getBilling().getCharge().remove(i);
			}
		}
		
		doctorNoShowFee();
	}
	
	public void doctorNoShowFee() {
		long time_diff = this.appointment.getOriginalDate(this.appointment.getAppointment()).getTime() - 
				this.appointment.getCurrTime().getTime();
		
		if((time_diff / (1000.0 * 60.0 * 60))< 24) {
			//System.out.println(this.appointment.getOriginalDate(this.appointment.getAppointment()) + " " + (time_diff / (1000 * 60 * 60)) % 24);
			this.bill.getTreatmentList().add("No Show Fee");
			this.bill.getCharge().add(35.0);
		}
	}
	/*
	public void menu() {
		boolean wrongChoice = true;
		do {
			System.out.println("Choose either of the following (enter the number):\n1. Schedule an Appointment\n"
					+ "2. Reschedule an appointment\n3. Cancel an appointment\n4. Edit Medical History \n5. Logout");
			
			int choice = sc.nextInt();
			switch(choice) {
				case 1:
				{
					bookAppointment();
						//wrongChoice = false;
				}
				break;
				case 2:
				{
					//rescheduleAppointment();
				}
				break;
				case 3: 
				{
					cancelAppointment();
				}
				break;
				case 4:
				{
					editHistory();
				}
				break;
				case 5:
				{
					System.out.println("\n-------------Logged Out------------");
					wrongChoice = false;
				}
				break;
				default:
					System.out.println("\nERROR: Choose another option only from below...\n");
					//wrongChoice = true;
			}
		}while(wrongChoice);
	
	}
	*/
	
	public void viewProfile() {
		System.out.printf("%200.200s%n", "\n********************************************** PATIENT PROFILE ***********************************************\n");
		System.out.println("Name: " + this.name);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Age: " + this.age);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Date of Birth (mm/dd/yyyy): " + this.DOB);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Gender: " + this.gender);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Address: " + this.address);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Phone No: " +  this.phoneNo);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Email Id: " +  this.emailID);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Immunization Record: ");
		
		for(String immunization: this.immunizationRecord) {
			System.out.println(immunization);
		}
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
	}
	//Methods
	//public void addScheduleForm();
	
	

}
