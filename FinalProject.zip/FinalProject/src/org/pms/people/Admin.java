package org.pms.people;
import org.pms.hospital.*;

import java.util.ArrayList;
import java.util.Scanner;

public class Admin extends Staff{
	
	//Fields
	//private ArrayList<ScheduleForm> listOfScheduleForms;
	private ArrayList<ProcedureForm> listOfProcedureForms = new ArrayList<ProcedureForm>();
	private ArrayList<LabRequestForm> listOfLabRequestForms = new ArrayList<LabRequestForm>();
	private Lab lab;
	Scanner sc = new Scanner(System.in);
	
	//Constructor
	public Admin() {
		this.listOfProcedureForms = new ArrayList<ProcedureForm>();
		this.listOfLabRequestForms = new ArrayList<LabRequestForm>();
		lab = null;

	}
	
	public ArrayList<ProcedureForm> getListOfProcedureForms() {
		return listOfProcedureForms;
	}
	
	public ArrayList<LabRequestForm> getListOfLabRequestForms(){
		return listOfLabRequestForms;
	}
	
	public void addToListOfProcedureForms(ProcedureForm form) {
		this.listOfProcedureForms.add(form);
	}
	
	public void addToListOfLabRequestForms(LabRequestForm form) {
		this.listOfLabRequestForms.add(form);
	}
	
	
	public Lab getLab() {
		return lab;
	}

	public void setLab(Lab lab) {
		this.lab = lab;
	}

	//Function to print out Procedure form 
	public void viewForm(ProcedureForm form) {
		System.out.println("********************************* Procedure Form *********************************");
		System.out.println("Doctor: " + form.getAppointment().getDoctor().getName() + "		Id: " + form.getAppointment().getDoctor().getID());
		System.out.println("Appointment: " + form.getAppointment().getAppointment());
		
	}
	
	//Function to print out LabReport Form
	public void viewForm(LabRequestForm form) {
		System.out.println("********************************* Lab Request Form *********************************");
		System.out.println("Doctor: " + form.getDoctor().getName() + "		Id: " + form.getDoctor().getID());
		System.out.println("Patient: " + form.getDoctor().getName() + "		Id: " + form.getPatient().getPatientID());
		System.out.println("Lab Procedure: " + form.getLabProcedure());
		
	}
	
	//Function to approve change in schedule
	public void approveProcedure(ProcedureForm form) {
		form.setApproved(true);
		form.getDoctor().getStringSchedule().remove(form.getDoctor().getSchedule().indexOf(form.getAppointment()));
		form.getDoctor().getSchedule().remove(form.getAppointment());
		form.getPatient().setAppointment(null);
		this.listOfProcedureForms.remove(form);
	}
	
	//Function to approve lab procedure
	public void approveLabRequest(LabRequestForm form) {

		form.setApproved(true);
		lab.addToListOfLabRequestForms(form);
		this.listOfLabRequestForms.remove(form);
	}
	
}
