package org.pms.people;
import org.pms.hospital.*;
//import org.pms.datafiles.Billing;
//import org.pms.datafiles.Chart;
//import org.pms.datafiles.History;
import java.util.*;

public class Patient extends Person{
	
	//Fields
	protected Chart chart;
	protected Billing bill;
	protected History history;
	protected int patientID;
	protected double weight; 
	protected double height;  
	protected Doctor doctor; 
	protected Hospital h;
	protected ArrayList<String> immunizationRecord = new ArrayList<String>();
	protected Appointment appointment;
	Scanner sc = new Scanner(System.in);
	protected ArrayList<LabReport> listOfLabReports = new ArrayList<LabReport>();
	
	
	//Constructor
	public Patient() {
		this.chart = null;
		this.bill = null;
		this.history = null;
		this.patientID = 0;
		this.weight = 0.0; 
		this.height = 0.0;  
		this.doctor = null; 
		this.immunizationRecord = new ArrayList<String>();
		this.listOfLabReports = new ArrayList<LabReport>();
		appointment = null;
	}
	
	//Getters and Setters
	public Chart getChart() {
		return this.chart;
	}
	public void setChart(Chart c) {
		this.chart = c;
		c.setP(this);
	}
	
	
	public ArrayList<LabReport> getListOfLabReports() {
		return listOfLabReports;
	}

	public void addToListOfLabReports(LabReport lr) {
		this.listOfLabReports.add(lr);
	}

	public Billing getBilling() {
		return this.bill;
	}
	public void setBill(Billing v) {
		this.bill = v;
	}
	public History getHistory() {
		return history;
	}
	public void setHistory(History history) {
		this.history = history;
	}
	public int getPatientID() {
		return patientID;
	}
	public void setPatientID(int patientID) {
		this.patientID = patientID;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
		doctor.addPatient(this);
	}
	
	public Hospital getH() {
		return h;
	}

	public void setH(Hospital h) {
		this.h = h;
	}
	
	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	
	public void addImmunization(String immunization) {
		this.immunizationRecord.add(immunization);
	}
	
	//Methods
	public void getImmunizationRecord() {
		for(String record : immunizationRecord) {
			System.out.println(record + "\n");
		}
	}
	
	public void viewProfile() {
		System.out.printf("%200.200s%n", "\n********************************************** PATIENT PROFILE ***********************************************\n");
		System.out.println("Name: " + this.name);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Age: " + this.age);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Date of Birth (mm/dd/yyyy): " + this.DOB);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Gender: " + this.gender);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Address: " + this.address);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Phone No: " +  this.phoneNo);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Email Id: " +  this.emailID);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Immunization Record: ");
		
		for(String immunization: this.immunizationRecord) {
			System.out.println(immunization);
		}
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		
	}
	
	
}
