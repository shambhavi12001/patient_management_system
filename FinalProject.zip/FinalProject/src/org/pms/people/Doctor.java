package org.pms.people;

//import org.pms.datafiles.Schedule;
import org.pms.hospital.*;

import java.text.SimpleDateFormat;
import java.util.*;
public class Doctor	extends Staff {

	//Fields
	Hospital h;
	Department department;
	ArrayList<Appointment> schedule = new ArrayList<Appointment>();
	ArrayList<String> stringSchedule = new ArrayList<String>();
	ArrayList<String> availableDates = new ArrayList<String>();
	ArrayList<ArrayList<String>> availableSlots = new ArrayList<ArrayList<String>>();
	ArrayList<Patient> patientList = new ArrayList<Patient>();
	ArrayList<InPatient> inPatientList = new ArrayList<InPatient>();
	ProcedureForm form; 
	Scanner sc = new Scanner(System.in);
	//Constructor
	public Doctor() {
		this.department = null;
		this.schedule = new ArrayList<Appointment>();
		this.form = null;
		this.h = null;
	}
	
	//Getters and Setters
	
	public Department getDepartment() {
		return this.department;
	}
	public void setDepartment(Department  dept) {
		this.department = dept;
	}
	
	public ArrayList<String> getStringSchedule(){
		return this.stringSchedule;
	}
	
	public ArrayList<Appointment> getSchedule() {
		return schedule;
	}
	
	public ArrayList<String> getAvailableDates() {
		return availableDates;
	}
	
	public ArrayList<ArrayList<String>> getAvailableSlots() {
		return availableSlots;
	}

	
	public ArrayList<Patient> getPatientList() {
		return patientList;
	}
	
	//Adding patient to patient list
	public void addPatient(Patient p)
	{
		this.patientList.add(p);
	}

	//adding appointment to schedule
	public void addToSchedule(Appointment appt) {//need to arrange schedule
		if(schedule.size() == 0) {
			this.schedule.add(appt);
		}
		else if(appt.getOriginalDate(appt.getAppointment()).compareTo(this.schedule.get(this.schedule.size()-1).getOriginalDate(this.schedule.get(this.schedule.size()-1).getAppointment()))
				> 0) {
			this.schedule.add(appt);
		}
		else {
			for(Appointment appointment: this.schedule) {
				if(appt.getOriginalDate(appt.getAppointment()).compareTo(appointment.getOriginalDate(appointment.getAppointment())) < 0){
					this.schedule.add(this.schedule.indexOf(appointment), appt);
					break;
				}
			}
		}
		stringSchedule.add(this.schedule.indexOf(appt), this.schedule.indexOf(appt) + 1 + ". Patient: " + appt.getPatient().getName() + "\n" + appt.getAppointment());
		
	}
	
	//discharging patient
	public void dischargePatient() {
		InPatient patient = null;
		System.out.println("Enter patient id to edit patient chart: ");
		int id = sc.nextInt();
		for(InPatient p: this.inPatientList) {
			if(p.getPatientID() == id) {
				patient = p;
				break;
			}
		}
		if(!Objects.isNull(patient)) {
			patient.setDischarged(true);
			this.inPatientList.remove(patient);
		}
		
	}
	
	//generating availabilty of doctor
	public void generateAvailability() {
		this.availableDates = new ArrayList<String>();
		this.availableSlots = new ArrayList<ArrayList<String>>();
		Calendar calendar = Calendar.getInstance();
		String AM_PM, minute, hour, date, day, month;
		int checkDate, noOfDates = 0;
		boolean conflict;
		//Date currDate = calendar.getTime();
		calendar.add(Calendar.MINUTE, 30);

		do {
			if(calendar.get(Calendar.DATE) < 10) {
				date = "0" + calendar.get(Calendar.DATE);
			}
			else {
				date = "" + calendar.get(Calendar.DATE);
			}
			if(calendar.get(Calendar.MONTH) + 1 < 10) {
				month = "0" + (calendar.get(Calendar.MONTH) + 1);
			}
			else {
				month = "" + (calendar.get(Calendar.MONTH) + 1);
			}
			checkDate = calendar.get(Calendar.DATE);
			day = new SimpleDateFormat("EE").format(calendar.getTime());
			
			
			this.availableSlots.add(new ArrayList<String>());
			
			do {
				conflict = false;
					if(calendar.get(Calendar.HOUR) < 1 && (calendar.get(Calendar.AM_PM) == Calendar.PM)|| 
							calendar.get(Calendar.HOUR) >= 11 && (calendar.get(Calendar.AM_PM) == Calendar.AM)) {
						if(calendar.get(Calendar.MINUTE) < 30) {
							minute = "00";
						}
						else {
							minute = "30";
						}
						if(calendar.get(Calendar.HOUR) == 0) {
							hour = "12";
						}
						else if(calendar.get(Calendar.HOUR) < 10) {
							hour = "0" + calendar.get(Calendar.HOUR);
						}
						else {
							hour = "" + calendar.get(Calendar.HOUR);
						}
						AM_PM = (calendar.get(Calendar.AM_PM) == Calendar.AM)? "AM":"PM";
						if(schedule.size() == 0) {
							//System.out.println("INDEX: " + index);
							
							if(!this.availableDates.contains(month + "/" + date + "/" + (calendar.get(Calendar.YEAR)) + ", " + day)){
								availableDates.add(month + "/" + date + "/" + (calendar.get(Calendar.YEAR))+ ", " + day);	
							}
							this.availableSlots.get(this.availableDates.size()-1).add(hour + ":" + minute + " " + AM_PM);
						}
						else {
								String o = month + "/" + date + "/" + (calendar.get(Calendar.YEAR)) + ", " + day
									 + " " + hour + ":" + minute + " " + AM_PM;
								for(Appointment slot: schedule) {
									if(slot.getAppointment().equals(o)) {
										System.out.println("EQUAL: " + slot.getAppointment());
										conflict = true;
									}
								}
								if(!conflict) {
									//System.out.println("ADDING: " + month + "/" + date + "/" + (calendar.get(Calendar.YEAR)) + ", " + day
														//+ " " + hour + ":" + minute + " " + AM_PM);
												
									
									if(!this.availableDates.contains(month + "/" + date + "/" + (calendar.get(Calendar.YEAR)) + ", " + day)){
										availableDates.add(month + "/" + date + "/" + (calendar.get(Calendar.YEAR))+ ", " + day);	
									}
									this.availableSlots.get(this.availableDates.size()-1).add(hour + ":" + minute + " " + AM_PM);
								}

							}
						//this.availableSlots.get(index).add(hour + ":" + minute + " " + AM_PM);

					}
					
					calendar.add(Calendar.MINUTE, 30);
					
			}while(checkDate == calendar.get(Calendar.DATE));
			
			noOfDates++;
			
		} while(noOfDates < 30); 
		/*
		for(String dates: this.availableDates) {
			System.out.println(dates);
			for(int i = 0; i < this.availableSlots.get(availableDates.indexOf(dates)).size(); ++i) {
				System.out.println(availableSlots.get(availableDates.indexOf(dates)).get(i));
			}
		}
		*/

		
	}
	
	//printing available dates
	public void printAvailableDates() {
		for(String date : this.availableDates) {
			
		}
	}
	
	public void printSchedule() {
		for(Appointment appt: this.schedule) {
			System.out.println((this.schedule.indexOf(appt) + 1) + ". Patient: " + appt.getPatient().getName() + "\n" + appt.getAppointment());
		}
		
	}
	public void addToStringSchedule(Appointment appt) {
		stringSchedule.add((this.schedule.indexOf(appt) + 1) + ". Patient: " + appt.getPatient().getName() + "\n" + appt.getAppointment());
	}
	
	//Printing Chart
	public void viewChart() {
		System.out.println("Enter patient id to edit patient chart: ");
		int id = sc.nextInt();
		for(Patient p: this.patientList) {
			if(p.getPatientID() == id) {
				p.getChart().viewChart();
				break;
			}
		}
		
	}
	
	public void editChart() {
		System.out.println("Enter patient id to edit patient chart: ");
		int id = sc.nextInt();
		for(Patient p: this.patientList) {
			if(p.getPatientID() == id) {
				p.getChart().viewChart();
				break;
			}
		}
		int choice;
		System.out.println("Choose:\n1. Edit Diagnosis\n2. Edit Medication\n3. Add Notes\n4. Back");
		choice = sc.nextInt();
		
		boolean wrongChoice = true;
		do {
			
			switch(choice) {
				case 1:
				{
					System.out.println("Patient List size:" + patientList.size());
					printSchedule();
				}
				break;
				case 2:
				{
					viewChart();
				}
				break;
				case 3: 
				{
					editChart();
				}
				break;
				case 4:
				{
					System.out.println();
					wrongChoice = false;
				}
				break;
				default:
					System.out.println("\nERROR: Choose another option only from below...\n");
			}
					
		}while(wrongChoice);
			
		
	}
	
	//Cancel request in change of appointment
	public boolean cancelRequest(int ch) {
		//printSchedule();
		boolean possible;
		
		long time_diff = this.schedule.get(ch).getOriginalDate(this.schedule.get(ch).getAppointment()).getTime() - 
				this.schedule.get(ch).getCurrTime().getTime();
		System.out.println((time_diff / (1000.0 * 60.0 * 60)));
		if((time_diff / (1000.0 * 60.0 * 60)) > 48) {
			possible = true;
			form = new ProcedureForm();
			form.setAppointment(this.schedule.get(ch));
			form.setDoctor(this.schedule.get(ch).getDoctor());
			form.setPatient(this.schedule.get(ch).getPatient());
			h.getAdmin().addToListOfProcedureForms(form);
			
			//TODO
			/*
			schedule.remove(ch);
			stringSchedule.remove(ch);
			*/
		}
		else {
			possible = false;
		}
		return possible;
		
	}
	
	public void setH(Hospital h) {
		this.h = h;
	}

	
	//Methods
	
	//public void requesteProcedure();
	//public void admit();
	//public void discharge();
}
