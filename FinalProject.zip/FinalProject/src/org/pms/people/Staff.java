package org.pms.people;

public class Staff extends Person {
	
	//Fields
	private int iD;
	private String password;
	
	//Constructor
	public Staff() {
		this.iD = 0;
		this.password = "unknown";
	}
	
	//Getters and Setters
	public int getID() {
		return this.iD;
	}
	public void setID(int i) {
		this.iD = i;
	}
	
	//Methods
	public boolean checkPassword(String pass) {
		if(pass.equals(this.password)) {
			return true;
		}
		return false;
	}
	
}
