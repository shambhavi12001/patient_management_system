package org.pms.people;

import java.util.ArrayList;

import org.pms.hospital.Hospital;

public class Nurse extends Staff{
	
	//Fields
	private ArrayList<InPatient> listOfPatients;
	private Hospital h;
	
	//Constructor
	public Nurse() {
		this.listOfPatients = new ArrayList<InPatient>();
	}
	
	public Hospital getH() {
		return h;
	}

	public void setH(Hospital h) {
		this.h = h;
	}



	//Getters and Setters
	public ArrayList<InPatient> getListOfPatients() {
		return this.listOfPatients;
	}
	
 	//Methods
	public void addInPatient(InPatient e) {
		this.listOfPatients.add(e);
	}
	
	public void removePatient(InPatient e) {
		if(this.listOfPatients.contains(e)) {
			this.listOfPatients.remove(e);
		}
		else {
			System.out.println("Error");
		}
	}
	
}
