package org.pms.hospital;
import org.pms.people.*;
import java.util.ArrayList;

//import project.people.Doctor;

public class Department {
	
	//Fields
	private String name;
	private ArrayList<Doctor> doctorList;
	private Hospital h;
	
	
	public void setH(Hospital h) {
		this.h = h;
	}

	//Constructor
	public Department() {
		this.name = null;
		this.doctorList = new ArrayList<Doctor>();
	}
	
	//Getters and Setters
	public String getName() {
		return this.name;
	}
	public void setName(String s) {
		this.name = s;
	}

	public ArrayList<Doctor> getDoctorList() {
		return doctorList;
	}

	public void addDoctor(Doctor doctor) {
		this.doctorList.add(doctor);
		doctor.setDepartment(this);
	}
	
	//Methods
}
