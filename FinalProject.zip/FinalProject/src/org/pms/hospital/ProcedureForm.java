package org.pms.hospital;
import org.pms.people.*;

public class ProcedureForm {
	private boolean approved;
	private Appointment appointment;
	private Doctor doctor;
	private Patient patient;
	
	
	public ProcedureForm() {
		this.approved = false;
		this.appointment = null;
		doctor = null;
		patient = null;
	}
	public boolean isApproved() {
		return approved;
	}
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	public Appointment getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
}
