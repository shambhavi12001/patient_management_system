package org.pms.hospital;

import org.pms.people.*;
import java.util.*;
public class LabReport {
	
	//Fields
	private Patient patient;
	private double cost;
	private ArrayList<String> tests = new ArrayList<String>();
	private ArrayList<String> results = new ArrayList<String>();
	
	//Constructor
	public LabReport() {
		this.setPatient(null);	
		tests = new ArrayList<String>();
		results = new ArrayList<String>();
		this.cost = 0.0;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
		
	}

	//Getters and Setters
	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public ArrayList<String> getTests() {
		return tests;
	}

	public void setTests(ArrayList<String> tests) {
		this.tests = tests;
	}

	public ArrayList<String> getResults() {
		return results;
	}

	public void setResults(ArrayList<String> results) {
		this.results = results;
	}
	
	public void addToResults(String result) {
		this.results.add(result);
	}
	
	public void addToTests(String test) {
		this.tests.add(test);
	}
	
	
	//function  to printlab reports
	public void printLabReport() {
		System.out.println("********************************* Lab Report *********************************");
		System.out.println("Patient: " + this.getPatient().getName() + "		Id: " + this.getPatient().getPatientID());
		System.out.printf("%10s	%10s", "Tests", "Results");
		for(int i = 0; i < tests.size(); ++i) {
			System.out.printf("%10s	%10s", tests.get(i), results.get(i));
		}
	}
	//Methods
	
}
