package org.pms.hospital;

import java.util.Calendar;

import java.util.Scanner;

import org.pms.people.Admin;
import org.pms.people.Doctor;
import org.pms.people.InPatient;
import org.pms.people.Nurse;
import org.pms.people.OutPatient;
import org.pms.people.Patient;
import org.pms.people.Person;

public class Driver {
	public static void main(String args[]) {
		
		//
		Calendar calendar = Calendar.getInstance();
		System.out.println(calendar.getTime());
		
		//Instantiate Hospital
		Hospital h = new Hospital();
		
		//Instantiate Departments and add to Hospital
		Department dpt1 = new Department();
		Department dpt2 = new Department();
		Department dpt3 = new Department();
		Department dpt4 = new Department();
		Department dpt5 = new Department();
		Department dpt6 = new Department();
		Department dpt7 = new Department();
		Department dpt8 = new Department();
		
		dpt1.setName("Cardiology");
		dpt4.setName("Radiology");
		dpt2.setName("Intensive Care Medicine");
		dpt3.setName("Gynaecology");
		dpt5.setName("Oncology");
		dpt6.setName("ENT");
		dpt7.setName("NeoNatal Care");
		dpt8.setName("Psych");
		
		h.addDepartmentList(dpt1);
		h.addDepartmentList(dpt2);
		h.addDepartmentList(dpt3);
		h.addDepartmentList(dpt4);
		h.addDepartmentList(dpt6);
		h.addDepartmentList(dpt5);
		h.addDepartmentList(dpt7);
		h.addDepartmentList(dpt8);
		
		
		
		//Instantiate Doctors and adding to Departments
		Doctor d1 = new Doctor();
		Doctor d2 = new Doctor();
		Doctor d3 = new Doctor();
		Doctor d4 = new Doctor();
		Doctor d5 = new Doctor();
		Doctor d6 = new Doctor();
		Doctor d7 = new Doctor();
		Doctor d8 = new Doctor();
		Doctor d9 = new Doctor();
		Doctor d10 = new Doctor();
		
		d1.setName("Dr. Mary Pearl");
		d2.setName("Dr. Tim Brody");
		d3.setName("Dr. Eva Collins");
		d4.setName("Dr. Mellissa Hunt");
		d5.setName("Dr. George Madden");
		d6.setName("Dr. Kim Taehyung");
		d7.setName("Dr. Nikhi Kumar");
		d8.setName("Dr. Mark Gregson");
		d9.setName("Dr. Harry Smith");
		d10.setName("Dr. Frank Herbert");
		
		dpt1.addDoctor(d1);
		dpt2.addDoctor(d2);
		dpt3.addDoctor(d3);
		dpt4.addDoctor(d4);
		dpt5.addDoctor(d5);
		dpt6.addDoctor(d6);
		dpt7.addDoctor(d7);
		dpt8.addDoctor(d8);
		dpt1.addDoctor(d9);
		dpt2.addDoctor(d10);
		
		h.addToDoctorList(d1);
		h.addToDoctorList(d2);
		h.addToDoctorList(d3);
		h.addToDoctorList(d4);
		h.addToDoctorList(d5);
		h.addToDoctorList(d6);
		h.addToDoctorList(d7);
		h.addToDoctorList(d8);
		h.addToDoctorList(d9);
		h.addToDoctorList(d10);
		
		d1.setUsername("doctor1");
		d2.setUsername("doctor2");
		d3.setUsername("doctor3");
		d4.setUsername("doctor4");
		d5.setUsername("doctor5");
		d6.setUsername("doctor6");
		d7.setUsername("doctor7");
		d8.setUsername("doctor8");
		d9.setUsername("doctor9");
		d10.setUsername("doctor10");
		
		d1.setPassword("one");
		d2.setPassword("two");
		d3.setPassword("three");
		d4.setPassword("four");
		d5.setPassword("five");
		d6.setPassword("six");
		d7.setPassword("seven");
		d8.setPassword("eight");
		d9.setPassword("nine");
		d10.setPassword("ten");
		
		//Instanitating Nurses
		Nurse n6 = new Nurse();
		Nurse n7 = new Nurse();
		Nurse n8 = new Nurse();
		Nurse n9 = new Nurse();
		Nurse n10 = new Nurse();
		
		n6.setName("John Blofis");
		n7.setName("Sofia Navarro");
		n8.setName("Jackie Peters");
		n9.setName("Maya Kapoor");
		n10.setName("Dave Leroy");
		
		n6.setUsername("nurse1");
		n7.setUsername("nurse2");
		n8.setUsername("nurse3");
		n9.setUsername("nurse4");
		n10.setUsername("nurse6");
		
		n6.setPassword("1_ece");
		n7.setPassword("2_ece");
		n8.setPassword("3_ece");
		n9.setPassword("4_ece");
		n10.setPassword("5_ece");
		
		h.addToNurseList(n6);
		h.addToNurseList(n7);
		h.addToNurseList(n8);
		h.addToNurseList(n9);
		h.addToNurseList(n10);
		
		
		
		//Instantiating OutPatients
		OutPatient p1 = new OutPatient();
		p1.setH(h);
		p1.setPassword("ece373_1");
		p1.setName("person1");
		p1.setDOB("10/01/2001");
		p1.setAddress("1333 N Tyndall Ave Tucson, AZ- 85719");
		p1.setGender('F');
		p1.setPhoneNo("(551) 399-9100");
		p1.setEmailID("alexsmith2001@gmail.com");
		p1.setAge(20);
		Billing b1 = new Billing();
		p1.setBill(b1);
		Chart c1 = new Chart();
		p1.setChart(c1);
		c1.setCurrentDiagnosis("Pain in thoracic spine (M54.6)");
		c1.setCurrentMedication("SELF-CARE/HOME MANAGEMENT TRAINING 15-30 MINS (2 UNITS) (97535) QTY x 2");
		c1.addNotes("No Decreased ROM. \n"
				+ "+ Decreased Strength + Increased Pain. No Increased Edema, No Abnormal Gait, and No Decreased Proprioception. \n"
				+ "Patient with bilateral thoracic spine pain consistent with postural weakness. She will benefit from skilled \n"
				+ "physical therapy for local treatment to decrease pain and for development of comprehensive core and postural \n"
				+ "strength program. Moderate discomfort with foam rolling but patient noted \"I feel better\" after completing \n"
				+ "soft tissue mobilization. Patient unable to stay for full session today due to class commitment.");
		History h1 = new History();
		p1.setHistory(h1);
		h1.setFamilyHistory("Father: Diagnosed with Diabetes");
		h1.setMedicalHistory("Thoracic Back Injury in 2011");
		p1.setWeight(180.0);
		p1.setHeight(180.1);
		p1.addImmunization("MMR Vaccine, 6/16/2003");
		p1.addImmunization("MMR Vaccine, 2/12/2003");
		p1.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p1.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p1.addImmunization("Rubella, 3/4/2021");
		p1.addImmunization("Measles, 12/6/2021");
		p1.setPatientID(2098);
		p1.setDoctor(d1);
		
		OutPatient p2 = new OutPatient();
		p2.setName("person2");
		p2.setH(h);
		p2.setPassword("ece373_2");
		p2.setDOB("10/05/2001");
		p2.setAddress("1033 N Main St Tucson, AZ- 85719");
		p2.setGender('M');
		p2.setPhoneNo("(551) 399-9100");
		p2.setEmailID("davidLock2009@gmail.com");
		p2.setAge(20);
		Billing b2 = new Billing();
		p2.setBill(b2);
		Chart c2 = new Chart();
		p2.setChart(c2);
		c2.setCurrentDiagnosis("Broken Right Femur");
		c2.setCurrentMedication("Morphine std dose");
		c2.addNotes(" Patient Complaining of Extreme Pain ");
		History h2 = new History();
		p2.setHistory(h2);
		h2.setFamilyHistory("Father: Diagnosed with Diabetes");
		h2.setMedicalHistory(" Allergic to Novvaflax ");
		p2.setWeight(180.0);
		p2.setHeight(180.1);
		p2.addImmunization("MMR Vaccine, 6/16/2003");
		p2.addImmunization("MMR Vaccine, 2/12/2003");
		p2.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p2.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p2.addImmunization("Rubella, 3/4/2021");
		p2.addImmunization("Measles, 12/6/2021");
	    p2.setPatientID(1111);
	    p2.setDoctor(d2);
		
	    OutPatient p3 = new OutPatient();
		p3.setH(h);
		p3.setName("person3");
		p3.setPassword("ece373_3");
		p3.setDOB("10/05/2001");
		p3.setAddress("1033 N Main St Tucson, AZ- 85719");
		p3.setGender('M');
		p3.setPhoneNo("(551) 399-9100");
		p3.setEmailID("balboarocky2009@gmail.com");
		p3.setAge(20);
		Billing b3 = new Billing();
		p3.setBill(b3);
		Chart c3 = new Chart();
		p3.setChart(c3);
		c3.setCurrentDiagnosis("Broken Right Femur");
		c3.setCurrentMedication("Morphine std dose");
		c3.addNotes(" Patient Complaining of Extreme Pain ");
		History h3 = new History();
		p3.setHistory(h3);
		h3.setFamilyHistory("Father: Diagnosed with Diabetes");
		h3.setMedicalHistory(" Allergic to Novvaflax ");
		p3.setWeight(180.0);
		p3.setHeight(180.1);
		p3.addImmunization("MMR Vaccine, 6/16/2003");
		p3.addImmunization("MMR Vaccine, 2/12/2003");
		p3.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p3.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p3.addImmunization("Rubella, 3/4/2021");
		p3.addImmunization("Measles, 12/6/2021");
		p3.setPatientID(1123);
		p3.setDoctor(d3);
		
		OutPatient p4 = new OutPatient();
		p4.setH(h);
		p4.setName("person4");
		p4.setPassword("ece373_4");
		p4.setDOB("12/07/2001");
		p4.setAddress("1233 E Rocky Dr St Tucson, AZ- 85719");
		p4.setGender('F');
		p4.setPhoneNo("(551) 399-9100");
		p4.setEmailID("phannah2009@gmail.com");
		p4.setAge(20);
		Billing b4 = new Billing();
		p4.setBill(b4);
		Chart c4 = new Chart();
		p4.setChart(c4);
		c4.setCurrentDiagnosis("2nd Degree Burns on Forearm");
		c4.setCurrentMedication("Morphine std dose");
		c4.addNotes(" Patient Complaining of Extreme Pain ");
		History h4 = new History();
		p4.setHistory(h4);
		h4.setFamilyHistory("Mother: Leukemia");
		h4.setMedicalHistory(" History of blood clots ");
		p4.setWeight(180.0);
		p4.setHeight(180.1);
		p4.addImmunization("MMR Vaccine, 6/16/2003");
		p4.addImmunization("MMR Vaccine, 2/12/2003");
		p4.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p4.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p4.addImmunization("Rubella, 3/4/2021");
		p4.addImmunization("Measles, 12/6/2021");
	    p4.setPatientID(1451);
	    p4.setDoctor(d4);
		
		OutPatient p5 = new OutPatient();
		p5.setH(h);
		p5.setName("person5");
		p5.setPassword("ece373_5");
		p5.setDOB("03/09/2000");
		p5.setAddress("1555 N Wilshire Rd Tucson, AZ- 85719");
		p5.setGender('M');
		p5.setPhoneNo("(551) 399-9100");
		p5.setEmailID("kyletayalegend@gmail.com");
		p5.setAge(20);
		Billing b5 = new Billing();
		p5.setBill(b5);
		Chart c5 = new Chart();
		p5.setChart(c5);
		c5.setCurrentDiagnosis(" Heart Palpitations ");
		c5.setCurrentMedication(" Home-Rest and Novvaflax ");
		c5.addNotes(" Patient is complaining of insomnia ");
		History h5 = new History();
		p5.setHistory(h5);
		h5.setFamilyHistory("Father: Diagnosed with high BP");
		h5.setMedicalHistory(" Rare Blood type AB- ");
		p5.setWeight(180.0);
		p5.setHeight(180.1);
		p5.addImmunization("MMR Vaccine, 6/16/2003");
		p5.addImmunization("MMR Vaccine, 2/12/2003");
		p5.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p5.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p5.addImmunization("Rubella, 3/4/2021");
		p5.addImmunization("Measles, 12/6/2021");
	    p5.setPatientID(1100);
	    p5.setDoctor(d5);
		
	    
	    //Instantiating InPatients
	    InPatient p6 = new InPatient();
	    p6.setH(h);
		p6.setName("person6");
		p6.setPassword("ece373_6");
		p6.setDOB("07/09/2000");
		p6.setAddress("1555 S Drachman Rd Tucson, AZ- 85719");
		p6.setGender('M');
		p6.setPhoneNo("(551) 399-9100");
		p6.setEmailID("chrischris@gmail.com");
		p6.setAge(44);
		Billing b6 = new Billing();
		p6.setBill(b6);
		Chart c6 = new Chart();
		p6.setChart(c6);
		c6.setCurrentDiagnosis(" Heart Attack ");
		c6.setCurrentMedication(" medicine1 10mg 3*day ");
		c6.addNotes(" Extreme Fatigue ");
		History h6 = new History();
		p6.setHistory(h6);
		h6.setFamilyHistory("Father: Liver transplant ");
		h6.setMedicalHistory(" On blood thinners ");
		p6.setWeight(180.0);
		p6.setHeight(180.1);
		p6.addImmunization("MMR Vaccine, 6/16/2003");
		p6.addImmunization("MMR Vaccine, 2/12/2003");
		p6.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p6.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p6.addImmunization("Rubella, 3/4/2021");
		p6.addImmunization("Measles, 12/6/2021");
	    p6.setPatientID(1900);
	    Room r6 = new Room();
	    r6.setName(106);
	    r6.setPatient(p6);
	    p6.setDoctor(d6);
	    p6.setNurse(n6);

	    InPatient p7 = new InPatient();
	    p7.setH(h);
		p7.setName("person7");
		p7.setPassword("ece373_7");
		p7.setDOB("03/09/1978");
		p7.setAddress("1678 N 6th St Tucson, AZ- 85719");
		p7.setGender('F');
		p7.setPhoneNo("(551) 399-9100");
		p7.setEmailID("musixmc@gmail.com");
		p7.setAge(79);
		Billing b7 = new Billing();
		p7.setBill(b7);
		Chart c7 = new Chart();
		p7.setChart(c7);
		c7.setCurrentDiagnosis(" Pancreatic Cancer Stage 3 ");
		c7.setCurrentMedication(" Radiation and Chemotherapy ");
		c7.addNotes(" Nausea, Breathless, mole on right hand ");
		History h7 = new History();
		p7.setHistory(h7);
		h7.setFamilyHistory(" Unvaccinated Parents ");
		h7.setMedicalHistory(" Multiple surgeries to remove cancerous growth ");
		p7.setWeight(180.0);
		p7.setHeight(180.1);
		p7.addImmunization("MMR Vaccine, 6/16/2003");
		p7.addImmunization("MMR Vaccine, 2/12/2003");
		p7.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p7.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p7.addImmunization("Rubella, 3/4/2021");
		p7.addImmunization("Measles, 12/6/2021");
	    p7.setPatientID(5610);
	    Room r7 = new Room();
	    r7.setName(107);
	    r7.setPatient(p7);
	    p7.setDoctor(d7);
	    p7.setNurse(n7);
	    
	    InPatient p8 = new InPatient();
	    p8.setH(h);
		p8.setName("person8");
		p8.setPassword("ece373_8");
		p8.setDOB("02/30/1998");
		p8.setAddress("7855 N Horizon Dr Tucson, AZ- 85719");
		p8.setGender('M');
		p8.setPhoneNo("(551) 399-9100");
		p8.setEmailID("kyleLrens@gmail.com");
		p8.setAge(23);
		Billing b8 = new Billing();
		p8.setBill(b8);
		Chart c8 = new Chart();
		p8.setChart(c8);
		c8.setCurrentDiagnosis(" Medically induce Coma ");
		c8.setCurrentMedication(" Fluids, Blood, Morphine 3std dosage ");
		c8.addNotes(" Patient was in auto accident ");
		History h8 = new History();
		p8.setHistory(h8);
		h8.setFamilyHistory(" Unavailable ");
		h8.setMedicalHistory(" Broken vertebrae ");
		p8.setWeight(180.0);
		p8.setHeight(180.1);
		p8.addImmunization("MMR Vaccine, 6/16/2003");
		p8.addImmunization("MMR Vaccine, 2/12/2003");
		p8.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p8.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p8.addImmunization("Rubella, 3/4/2021");
		p8.addImmunization("Measles, 12/6/2021");
	    p8.setPatientID(1980);
	    Room r8 = new Room();
	    r8.setName(108);
	    r8.setPatient(p8);
	    p8.setDoctor(d8);
	    p8.setNurse(n8);
	   
	    InPatient p9 = new InPatient();
	    p9.setH(h);
		p9.setName("person9");
		p9.setPassword("ece373_9");
		p9.setDOB("03/09/1976");
		p9.setAddress("1555 N Wilshire Rd Tucson, AZ- 85719");
		p9.setGender('F');
		p9.setPhoneNo("(551) 399-9100");
		p9.setEmailID("jodiesweet@gmail.com");
		p9.setAge(43);
		Billing b9 = new Billing();
		p9.setBill(b9);
		Chart c9 = new Chart();
		p9.setChart(c9);
		c9.setCurrentDiagnosis(" Fainting Spells ");
		c9.setCurrentMedication(" Home-Rest and Fluids ");
		c9.addNotes(" Routine Check up ");
		History h9 = new History();
		p9.setHistory(h9);
		h9.setFamilyHistory("Family History of HypoThyroidism");
		h9.setMedicalHistory(" Elective plastice surgery ");
		p9.setWeight(180.0);
		p9.setHeight(180.1);
		p9.addImmunization("MMR Vaccine, 6/16/2003");
		p9.addImmunization("MMR Vaccine, 2/12/2003");
		p9.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p9.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p9.addImmunization("Rubella, 3/4/2021");
		p9.addImmunization("Measles, 12/6/2021");
	    p9.setPatientID(1100);
	    Room r9 = new Room();
	    r9.setName(109);
	    r9.setPatient(p9);
	    p9.setDoctor(d9);
	    p9.setNurse(n9);
	    
	    InPatient p10 = new InPatient();
	    p10.setH(h);
		p10.setName("person10");
		p10.setPassword("ece373_10");
		p10.setDOB("03/29/2012");
		p10.setAddress("1587 Univ Blvd Tucson, AZ- 85719");
		p10.setGender('M');
		p10.setPhoneNo(" ");
		p10.setEmailID(" ");
		p10.setAge(8);
		Billing b10 = new Billing();
		p10.setBill(b10);
		Chart c10 = new Chart();
		p10.setChart(c10);
		c10.setCurrentDiagnosis(" Heart Defect ");
		c10.setCurrentMedication(" Surgery ");
		c10.addNotes(" Fainting Spells and clots ");
		History h10 = new History();
		p10.setHistory(h10);
		h10.setFamilyHistory("Mother: Similar Heart defect corrected when 9");
		h10.setMedicalHistory(" Breech Birth ");
		p10.setWeight(180.0);
		p10.setHeight(180.1);
		p10.addImmunization("MMR Vaccine, 6/16/2003");
		p10.addImmunization("MMR Vaccine, 2/12/2003");
		p10.addImmunization("Pfizer Covid-19 Vaccine, 3/4/2021");
		p10.addImmunization("Pfizer Covid-19 Vaccine, 1/29/2021");
		p10.addImmunization("Rubella, 3/4/2021");
		p10.addImmunization("Measles, 12/6/2021");
	    p10.setPatientID(1100);
	    Room r10 = new Room();
	    r10.setName(110);
	    r10.setPatient(p10);
	    p10.setDoctor(d10);
	    p10.setNurse(n10);
	   
	    
	    //Adding Patients to hospital lists
		h.addToOutPatientList(p1);
		h.addToOutPatientList(p1);
		h.addToOutPatientList(p2);
		h.addToOutPatientList(p3);
		h.addToOutPatientList(p4);
		h.addToOutPatientList(p5);
		h.addToInPatientList(p6);
		h.addToInPatientList(p7);
		h.addToInPatientList(p8);
		h.addToInPatientList(p9);
		h.addToInPatientList(p10);
		
		h.addToPatientList(p1);
		h.addToPatientList(p1);
		h.addToPatientList(p2);
		h.addToPatientList(p3);
		h.addToPatientList(p4);
		h.addToPatientList(p5);
		h.addToPatientList(p6);
		h.addToPatientList(p7);
		h.addToPatientList(p8);
		h.addToPatientList(p9);
		h.addToPatientList(p10);
				
						
		Person person;
		Admin a = new Admin();
		a.setUsername("admin");
		a.setPassword("adminece373");
		
		h.setAdmin(a);
		
		Lab lab = new Lab();
		a.setLab(lab);
		
		//START GUI
		HospitalGUI gui = new HospitalGUI("Hospital Log In", h);
		
		

	}

}