package org.pms.hospital;

import org.pms.people.*;

public class LabRequestForm {
	
	//Fields
	private Patient patient;
	private Doctor doctor;
	private boolean approved;
	private boolean processed;
	private String LabProcedure;
	private String Lab;
	
	//Constructor
	
	public LabRequestForm() {
		patient = null;
		doctor = null;
		approved = false;
	}
	public boolean isApproved() {
		return approved;
	}

	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	//Getters and Setters
	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	public String getLabProcedure() {
		return LabProcedure;
	}
	public void setLabProcedure(String labProcedure) {
		LabProcedure = labProcedure;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public boolean isProcessed() {
		return processed;
	}
	public void setProcessed(boolean processed) {
		this.processed = processed;
	}

	
}
