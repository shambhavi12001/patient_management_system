package org.pms.hospital;

import java.awt.*;
import java.awt.event.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.*;

import org.pms.people.Admin;
import org.pms.people.Doctor;
import org.pms.people.InPatient;
import org.pms.people.Nurse;
import org.pms.people.OutPatient;
import org.pms.people.Patient;


public class HospitalGUI extends JFrame {
	
	//Instance of Hospital
	private Hospital h;
	
	private JPanel MainMenu;
	
	private JButton patient;
	private JButton doctor;
	private JButton nurse;
	private JButton admin;
	private JButton createNewAccount;
	
	//patient menu components
	private JFrame patientFrame;
	private JPanel patientPanel;
					
	private JButton patientViewProfile;
	private JButton patientEditProfile; // needs to be added
	private JButton patientBook;
	private JButton patientReschedule;
	private JButton patientCancel;
	private JButton patientViewAppt;
	private JButton patientViewAll;
	private JButton patientViewHistory;
	private JButton patientHistory; //needs to be changed
	private JButton patientExit;
	private JButton patientBilling;
	
	//doctor menu components
	private JFrame doctorFrame;
	private JPanel doctorPanel;
					
	private JButton doctorAllPatients;
	private JButton doctorViewSchedule;
	private JButton doctorViewChart;
	private JButton doctorCancel;
	private JButton doctorProcedure;
	private JButton doctorEditChart;
	private JButton doctorExit;
	private JButton doctorDischargePatient;
	
	//nurse menu components
	private JFrame nurseFrame;
	private JPanel nursePanel;
					
	private JButton nurseAllPatients;
	private JButton nurseEditChart;
	private JButton nurseViewChart; 
	private JButton nurseNew;
	private JButton nurseExit;
	
	//admin menu components
	private JFrame adminFrame;
	private JPanel adminPanel;
					
	private JButton adminAllPatients;
	private JButton adminApprove;
	private JButton adminProcedure;
	private JButton adminBilling; 
	private JButton adminExit;
	int screen_height, screen_width;
	
	private JFrame patientProfileFrame;
	private JPanel patientProfilePanel;
	
	private JFrame patientBookFrame;
	private JPanel patientBookPanel;
	private JButton cardiology;
	private JButton radiology;
	private JButton intensivecare;
	private JButton gynaecology;
	private JButton oncology;
	private JButton ent;
	private JButton neonatal;
	private JButton psych;
	
	private ArrayList<JButton> buttonList;
	private JButton back;
	
	private JFrame patientBookApptFrame;
	private JPanel patientBookApptPanel;
	
	private JFrame patientBookDateFrame;
	private JPanel patientBookDatePanel;
	
	private JFrame patientBookSlotFrame;
	private JPanel patientBookSlotPanel;
	
	private JFrame doctorCancelFrame;
	private JPanel doctorCancelPanel;
	
	private int index;
	Department d;
	
	//Constuctor of Main GUI
		public HospitalGUI(String windowTitle, Hospital hospital)
		{
			super(windowTitle);
		
			this.h = hospital;
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		    setSize(screenSize.width, screenSize.height);
		    screen_width = screenSize.width;
		    screen_height = screenSize.height;
			setSize(screen_width, screen_width);
		
			setLayout(new FlowLayout(FlowLayout.CENTER));
					
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			buildGUImainMenu();
			setVisible(true);
		
		}
	
		//Building main GUI
		public void buildGUImainMenu() 
		{
			MainMenu = new JPanel();
						
			patient = new JButton(" Patient ");
			doctor = new JButton(" Doctor ");
			nurse = new JButton(" Nurse ");
			admin = new JButton(" Admin ");
			createNewAccount = new JButton(" Create New Account ");
			
			patient.setPreferredSize(new Dimension(this.screen_width/10, this.screen_height/10));
			doctor.setPreferredSize(new Dimension(this.screen_width/10, this.screen_height/10));
			nurse.setPreferredSize(new Dimension(this.screen_width/10, this.screen_height/10));
			admin.setPreferredSize(new Dimension(this.screen_width/10, this.screen_height/10));
			createNewAccount.setPreferredSize(new Dimension(this.screen_width/10, this.screen_height/10));
			
			GridLayout gridLayout = new GridLayout(6,1);
			gridLayout.setVgap(15);
			
			MainMenu.setLayout(gridLayout);
			
			this.patient.addActionListener(new MainMenuListner());
			this.doctor.addActionListener(new MainMenuListner());
			this.nurse.addActionListener(new MainMenuListner());
			this.admin.addActionListener(new MainMenuListner());
			this.createNewAccount.addActionListener(new MainMenuListner());
			
			MainMenu.add(new JLabel("<HTML><center>Welcome to the Hospital" +
				"<BR>Choose an action from the Buttons below.</center></HTML>"));
			MainMenu.add(patient);
			MainMenu.add(doctor);
			MainMenu.add(nurse);
			MainMenu.add(admin);
			MainMenu.add(createNewAccount);
			
			this.add(MainMenu);
		}
		
		//Main menu actionlistener for buttons
		private class MainMenuListner implements ActionListener 
		{
			public void actionPerformed(ActionEvent e)
			{
				JButton source = (JButton)(e.getSource());
				
				if(source.equals(patient))
					handlePatient();
				else if(source.equals(doctor))
					handleDoctor();
				else if(source.equals(nurse))
					handleNurse();
				else if(source.equals(admin))
					handleAdmin();
				else if(source.equals(createNewAccount)) {
					handleCreateAccount();
				}
			}
			
			private void handlePatient() 
			{
				String inputName = "";
				String inputPassword = "";
				
				JTextField fieldName = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				Object [] message = {
						"Patient Name: ", fieldName,
						"Password: ", fieldPassword
				};
				
				//Enter login info
				int option = JOptionPane.showConfirmDialog(null, message, "Patient Log In", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{
					inputName = fieldName.getText();
					inputPassword = fieldPassword.getText();
					//Any entry Blank
					if((inputName.trim().equals("")) || (inputPassword.trim().equals(""))) 
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						//InPatient Exists
						if(h.ContainsInPatient(inputName) != null)
						{
							//check password
							InPatient inp = h.ContainsInPatient(inputName);
							if(inp.getPassword().compareTo(inputPassword) == 0)
							{
								handlePatientMenu(inp, null);
								System.out.println(inp.getName());
							}
							else
							{
								JOptionPane.showMessageDialog(null, 
										"Incorrect password entered by Patient " + inp.getName(),
										"Incorrect Password: Could not Log in.",
										JOptionPane.ERROR_MESSAGE);
							}
						}
						//OutPatient Exists
						else if(h.ContainsOutPatient(inputName) != null) 
						{
							//check password
							OutPatient outp = h.ContainsOutPatient(inputName);
							if(outp.getPassword().compareTo(inputPassword) == 0)
							{
								handlePatientMenu(null, outp);
								System.out.println(outp.getName());
							}
							else
							{
								JOptionPane.showMessageDialog(null, 
										"Incorrect password entered by Patient " + outp.getName(),
										"Incorrect Password: Could not Log in.",
										JOptionPane.ERROR_MESSAGE);
							}
						}
						else
						{
							//patient does not exist
							JOptionPane.showMessageDialog(null,
									"Patient " + inputName + " does not exist in this Hospital.",
									"Error",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
			private void handleDoctor()
			{
				String inputUserName = "";
				String inputPassword = "";
				
				JTextField fieldUserName = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				Object [] message = {
						"Username: ", fieldUserName,
						"Password: ", fieldPassword
				};
				
				//Enter login info
				int option = JOptionPane.showConfirmDialog(null, message, "Doctor Log In", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{
					inputUserName = fieldUserName.getText();
					inputPassword = fieldPassword.getText();
					//Any Entry Blank
					if((inputUserName.trim().equals("")) || (inputPassword.trim().equals(""))) 
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else 
					{
						//Doctor Exists
						if(h.ContainsDoctor(inputUserName) != null)
						{
							//Check Password
							Doctor d = h.ContainsDoctor(inputUserName);
							System.out.println(d.getName()+ d.getUsername() + d.getPassword());
							if(d.getPassword().compareTo(inputPassword) == 0)
							{
								handleDoctorMenu(d);
								System.out.println(d.getName());
								d.printSchedule();
							}
							else
							{
								JOptionPane.showMessageDialog(null, 
										"Incorrect password entered by Doctor " + d.getName(),
										"Incorrect Password: Could not Log in.",
										JOptionPane.ERROR_MESSAGE);
							}
						}
						else
						{
							//Doctor does not exist
							JOptionPane.showMessageDialog(null,
									"Doctor with username " + inputUserName + " does not exist in this Hospital.",
									"Error",
									JOptionPane.ERROR_MESSAGE);					
						}
					}
				}
			}
			private void handleNurse()
			{
				String inputUserName = "";
				String inputPassword = "";
				
				JTextField fieldUserName = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				Object [] message = {
						"Username: ", fieldUserName,
						"Password: ", fieldPassword
				};
				//Enter Log in info
				int option = JOptionPane.showConfirmDialog(null, message, "Nurse Log In", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{
					inputUserName = fieldUserName.getText();
					inputPassword = fieldPassword.getText();
					//Any Entry Blank
					if((inputUserName.trim().equals("")) || (inputPassword.trim().equals(""))) 
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						//Nurse Exists
						if(h.ContainsNurse(inputUserName) != null)
						{
							//Check Password
							Nurse n = h.ContainsNurse(inputUserName);
							if(n.getPassword().compareTo(inputPassword) == 0)
							{
								handleNurseMenu(n);
								System.out.println(n.getName());
							}
							else
							{
								JOptionPane.showMessageDialog(null, 
										"Incorrect password entered by Nurse " + n.getName(),
										"Incorrect Password: Could not Log in.",
										JOptionPane.ERROR_MESSAGE);
							}
						}
						else
						{
							//Nurse does not exist
							JOptionPane.showMessageDialog(null,
									"Nurse with username " + inputUserName + " does not exist in this Hospital.",
									"Error",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}
			}
			private void handleAdmin()
			{
				String inputUserName = "";
				String inputPassword = "";
				
				JTextField fieldUserName = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				Object [] message = {
						"Username: ", fieldUserName,
						"Password: ", fieldPassword
				};
				
				//Enter login info
				int option = JOptionPane.showConfirmDialog(null, message, "Admin Log In", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{
					inputUserName = fieldUserName.getText();
					inputPassword = fieldPassword.getText();
					//Any entry fields blank
					if((inputUserName.trim().equals("")) || (inputPassword.trim().equals(""))) 
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						//Admin Exists
						if(h.ContainsAdmin(inputUserName) != null)
						{
							//Check Password
							Admin a = h.ContainsAdmin(inputUserName);
							if(a.getPassword().compareTo(inputPassword) == 0)
							{
								handleAdminMenu(a);
								System.out.println(a.getName());
							}
							else
							{
								JOptionPane.showMessageDialog(null, 
										"Incorrect password entered by Admin " + a.getName(),
										"Incorrect Password: Could not Log in.",
										JOptionPane.ERROR_MESSAGE);
							}
						}
						else
						{
							//Admin does not exist
							JOptionPane.showMessageDialog(null,
									"Doctor with username " + inputUserName + " does not exist in this Hospital.",
									"Error",
									JOptionPane.ERROR_MESSAGE);
						}
					}
				}
				
			}
			
			//Create a new outPatient Account
			private void handleCreateAccount() {
				OutPatient p = new OutPatient();
				
				String Name;
				String DOB;
				int age;
				String address;
				char gender;
				String phoneNo;
				String emailID;
				String password;
				
				int choice;
				
				JTextField fieldName = new JTextField();
				JTextField fieldDOB = new JTextField();
				JTextField fieldAge = new JTextField();
				JTextField fieldAddress = new JTextField();
				JTextField fieldGender = new JTextField();
				JTextField fieldPhoneNo = new JTextField();
				JTextField fieldEmail = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				JTextField fieldIndex = new JTextField();
				int inputIndex = -1;
				
						
								
				Object [] message3 = {
					"Fields Mmarked with (*) cannot be left blank",
					"*Name:", fieldName,
					"DOB (MMDDYYYY)", fieldDOB,
					"Age: ", fieldAge,
					"Address: ", fieldAddress,
					"Gender: ", fieldGender,
					"Email: ", fieldEmail,
					"PhoneNo: ", fieldPhoneNo,
					"*Password:", fieldPassword
				};
								
				choice = JOptionPane.showConfirmDialog(null, message3, "New Patient Info", JOptionPane.OK_OPTION);
				if(choice == JOptionPane.OK_OPTION)
				{
					Name = fieldName.getText();
					password = fieldPassword.getText();
					
					if((Name.trim().equals("")) || (password.trim().equals("")))
					{
						JOptionPane.showMessageDialog(null,
						"Please enter fields correctly",
						"Error",
						JOptionPane.ERROR_MESSAGE);
					}
					else if(h.ContainsOutPatient(Name) != null) {
						p = h.ContainsOutPatient(Name);
						if(p.getPassword().equals(password)) {
							JOptionPane.showMessageDialog(null,
									"Account exists with the same name and password",
									"Error",
									JOptionPane.ERROR_MESSAGE);
						}
						else
						{
							DOB = fieldDOB.getText();
							address = fieldAddress.getText();
							
							if(!fieldGender.getText().trim().equals("")) {
								gender = fieldGender.getText().charAt(0);
								p.setGender(gender);
							}
						
							emailID = fieldEmail.getText();
							phoneNo = fieldPhoneNo.getText();
							h.addToOutPatientList(p);
							h.addToPatientList(p);
							p.setH(h);				
							p.setName(Name);
							p.setDOB(DOB);
							if(!fieldAge.getText().trim().equals("")) {
								age = Integer.parseInt(fieldAge.getText());
								p.setAge(age);
							}
							p.setAddress(address);
							
							p.setEmailID(emailID);
							p.setPhoneNo(phoneNo);
							p.setPassword(password);
							Billing b = new Billing();
							p.setBill(b);
							Chart c = new Chart();
							p.setChart(c);
							History history = new History();
							p.setHistory(history);
						}
						
					}
					
					else
					{
						DOB = fieldDOB.getText();
						address = fieldAddress.getText();
						
						if(!fieldGender.getText().trim().equals("")) {
							gender = fieldGender.getText().charAt(0);
							p.setGender(gender);
						}
					
						emailID = fieldEmail.getText();
						phoneNo = fieldPhoneNo.getText();
						h.addToOutPatientList(p);
						h.addToPatientList(p);
						p.setH(h);				
						p.setName(Name);
						p.setDOB(DOB);
						if(!fieldAge.getText().trim().equals("")) {
							age = Integer.parseInt(fieldAge.getText());
							p.setAge(age);
						}
						p.setAddress(address);
						
						p.setEmailID(emailID);
						p.setPhoneNo(phoneNo);
						p.setPassword(password);
						Billing b = new Billing();
						p.setBill(b);
						Chart c = new Chart();
						p.setChart(c);
						History history = new History();
						p.setHistory(history);
						
					}
				}
				

			}
			
			
			public void handlePatientMenu(InPatient inp, OutPatient outp) 
			{
				//Common menu
				patientFrame = new JFrame("Patient Menu");
				patientPanel = new JPanel();
								
				patientFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
				
				patientViewProfile = new JButton(" View Profile ");
				patientEditProfile = new JButton(" Edit Profile ");
				patientBook = new JButton(" Booking New Appointment ");
				patientReschedule = new JButton(" Reschedule Appointment ");
				patientCancel = new JButton(" Cancel Appointment ");
				patientViewAppt = new JButton(" View Appointment ");
				patientHistory = new JButton(" Edit Patient History ");
				patientViewHistory = new JButton(" View Patient History");
				patientViewAll = new JButton(" View Patient Chart ");
				patientBilling = new JButton(" Billing ");
				patientExit = new JButton(" Log Out ");
							
				GridLayout gridLayout = new GridLayout(11,1);
				gridLayout.setVgap(10);
				
				patientPanel.setLayout(gridLayout);
				
				patientViewProfile.addActionListener(new PatientListener(inp, outp));
				patientEditProfile.addActionListener(new PatientListener(inp, outp));
				patientBook.addActionListener(new PatientListener(inp, outp));
				patientReschedule.addActionListener(new PatientListener(inp, outp));
				patientCancel.addActionListener(new PatientListener(inp, outp));
				patientViewAppt.addActionListener(new PatientListener(inp, outp));
				patientHistory.addActionListener(new PatientListener(inp, outp));
				patientViewHistory.addActionListener(new PatientListener(inp, outp));
				patientViewAll.addActionListener(new PatientListener(inp, outp));
				patientBilling.addActionListener(new PatientListener(inp, outp));
				patientExit.addActionListener(new PatientListener(inp, outp));
				
				if(inp==null)
				{
					patientPanel.add(new JLabel("<HTML><center>Welcome " + outp.getName() +
							"<BR>Choose an action from the Buttons below.</center></HTML>"));
				}
				else
				{
					patientPanel.add(new JLabel("<HTML><center>Welcome " + inp.getName() +
							"<BR>Choose an action from the Buttons below.</center></HTML>"));
				}
				if(outp!=null) {
					patientPanel.add(patientViewProfile);
					patientPanel.add(patientEditProfile);
					patientPanel.add(patientBook);
					patientPanel.add(patientCancel);
					patientPanel.add(patientViewAppt);
					patientPanel.add(patientHistory);
					patientPanel.add(patientViewHistory);
					patientPanel.add(patientViewAll);
					patientPanel.add(patientBilling);
					patientPanel.add(patientExit);
				}
				else if(inp != null) {
					patientPanel.add(patientViewProfile);
					patientPanel.add(patientEditProfile);
					patientPanel.add(patientHistory);
					patientPanel.add(patientViewHistory);
					patientPanel.add(patientViewAll);
					patientPanel.add(patientBilling);
					patientPanel.add(patientExit);
				}

				patientFrame.add(patientPanel);
				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
				patientFrame.setSize(screenSize.width, screenSize.height);

				patientFrame.setVisible(true);
				/*
				if(inp != null)
				{
					//Inpatient menu
				}
				else if(outp != null)
				{
					//OutPatient menu
				}
				*/
			}
						
			public void handleDoctorMenu(Doctor d)
			{
				doctorFrame = new JFrame("Doctor Menu");
				doctorPanel = new JPanel();
								
				doctorFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
				
				doctorAllPatients = new JButton(" Print Patient List ");
				doctorViewSchedule = new JButton("View Schedule");
				doctorCancel = new JButton(" Request Cancel Appointment ");
				doctorProcedure = new JButton(" Request Lab Procedure ");
				doctorViewChart = new JButton(" View Patient Chart ");
				doctorEditChart = new JButton(" Edit Patient Chart ");
				doctorExit = new JButton(" Log Out ");
				
				GridLayout gridLayout = new GridLayout(8,1);
				gridLayout.setVgap(10);
				
				doctorPanel.setLayout(gridLayout);
				
				doctorAllPatients.addActionListener(new DoctorListener(d));
				doctorViewSchedule.addActionListener(new DoctorListener(d));
				doctorCancel.addActionListener(new DoctorListener(d));
				doctorProcedure.addActionListener(new DoctorListener(d));
				doctorEditChart.addActionListener(new DoctorListener(d));
				doctorViewChart.addActionListener(new DoctorListener(d));
				doctorExit.addActionListener(new DoctorListener(d));
								
				doctorPanel.add(new JLabel("<HTML><center>Welcome " + d.getName() +
					"<BR>Choose an action from the Buttons below.</center></HTML>"));
				doctorPanel.add(doctorAllPatients);
				doctorPanel.add(doctorViewSchedule);
				doctorPanel.add(doctorCancel);
				doctorPanel.add(doctorProcedure);
				doctorPanel.add(doctorViewChart);
				doctorPanel.add(doctorEditChart);
				doctorPanel.add(doctorExit);

				doctorFrame.add(doctorPanel);
				doctorFrame.setSize(screen_width, screen_height);
				doctorFrame.setVisible(true);
			}
			
			public void handleNurseMenu(Nurse n) 
			{
				nurseFrame = new JFrame("Nurse Menu");
				nursePanel = new JPanel();
								
				nurseFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
				
				nurseAllPatients = new JButton(" Print Patient List ");
				nurseEditChart = new JButton(" Edit Patient Chart ");
				nurseViewChart = new JButton(" View Patient Chart ");
				nurseNew = new JButton(" New Patient ");
				nurseExit = new JButton(" Log Out ");
				
				GridLayout gridLayout = new GridLayout(6,1);
				gridLayout.setVgap(10);
				
				nursePanel.setLayout(gridLayout);
				
				nurseAllPatients.addActionListener(new NurseListener(n));
				nurseEditChart.addActionListener(new NurseListener(n));
				nurseViewChart.addActionListener(new NurseListener(n));
				nurseNew.addActionListener(new NurseListener(n));
				nurseNew.addActionListener(new NurseListener(n));
								
				nursePanel.add(new JLabel("<HTML><center>Welcome " + n.getName() +
					"<BR>Choose an action from the Buttons below.</center></HTML>"));
				nursePanel.add(nurseAllPatients);
				nursePanel.add(nurseViewChart);
				nursePanel.add(nurseEditChart);
				nursePanel.add(nurseNew);
				nursePanel.add(nurseExit);

				nurseFrame.add(nursePanel);
				nurseFrame.setSize(350, 300);
				nurseFrame.setVisible(true);
			}
			
			public void handleAdminMenu(Admin a)
			{
				adminFrame = new JFrame("Admin Menu");
				adminPanel = new JPanel();
								
				adminFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
				
				adminAllPatients = new JButton(" Print Patient List ");
				adminApprove = new JButton(" Process Lab Requests ");
				adminProcedure = new JButton(" Approve Change in Schedule ");
				adminBilling = new JButton(" View Patient Billing ");
				adminExit = new JButton(" Log Out ");
				
				GridLayout gridLayout = new GridLayout(6,1);
				gridLayout.setVgap(10);
				
				adminPanel.setLayout(gridLayout);
				
				adminAllPatients.addActionListener(new AdminListener(a));
				adminApprove.addActionListener(new AdminListener(a));
				adminProcedure.addActionListener(new AdminListener(a));
				adminBilling.addActionListener(new AdminListener(a));
				adminExit.addActionListener(new AdminListener(a));
								
				adminPanel.add(new JLabel("<HTML><center>Welcome " + a.getName() +
					"<BR>Choose an action from the Buttons below.</center></HTML>"));
				adminPanel.add(adminAllPatients);
				adminPanel.add(adminApprove);
				adminPanel.add(adminProcedure);
				adminPanel.add(adminBilling);
				adminPanel.add(adminExit);

				adminFrame.add(adminPanel);
				
				adminFrame.setSize(screen_width, screen_height);
				adminFrame.setVisible(true);
			}
		}
		
		private class PatientListener implements ActionListener
		{
			InPatient inp = new InPatient();
			OutPatient outp = new OutPatient();
			
			public PatientListener(InPatient inpatient, OutPatient outpatient)
			{
				this.inp = inpatient;
				this.outp = outpatient;
			}
			
			public void actionPerformed(ActionEvent e)
			{
				JButton source = (JButton)(e.getSource());
				
				if(source.equals(patientViewProfile))
					handlePatientViewProfile(inp, outp);
				else if(source.equals(patientEditProfile))
					handlePatientEditProfile(inp, outp);
				else if(source.equals(patientBook))
					handlePatientBook(inp, outp);
				else if(source.equals(patientCancel))
					handlePatientCancel(inp, outp);
				else if(source.equals(patientViewAppt))
					handlePatientViewAppt(inp, outp);
				else if(source.equals(patientHistory))
					handlePatientHistory(inp, outp);
				else if(source.equals(patientViewHistory))
					handlePatientViewHistory(inp, outp);
				else if(source.equals(patientViewAll))
					handlePatientViewAll(inp, outp);
				else if(source.equals(patientBilling))
					handlePatientBilling(inp, outp);
				else if(source.equals(patientExit))
					handlePatientExit(inp, outp);
				
			}
			
			//Patient View profile
			private void handlePatientViewProfile(InPatient inp, OutPatient outp) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);

				if(inp != null) {
					inp.viewProfile();
				}
				else if(outp != null) {
					outp.viewProfile();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"View Profile", 
						JOptionPane.PLAIN_MESSAGE);
			}
				
			
			//Patient edit profile
			private void handlePatientEditProfile(InPatient inp, OutPatient outp) {
				String inputName = null;
				String inputAddress = null;
				String inputAge = null;
				String inputDOB = null;
				String inputPhoneNo = null;
				String inputEmailId = null;
				String inputGender = null;
				String inputImmunization = null;

				
				JTextField fieldName = new JTextField();
				JTextField fieldAddress = new JTextField();
				JTextField fieldAge = new JTextField();
				JTextField fieldDOB = new JTextField();
				JTextField fieldPhoneNo = new JTextField();
				JTextField fieldEmailId = new JTextField();
				JTextField fieldGender = new JTextField();
				JTextField fieldImmunization = new JTextField();
				
				Object [] message = {
						"Name ", fieldName,
						"Address ", fieldAddress,
						"Age ", fieldAge,
						"DOB ", fieldDOB,
						"Phone No ", fieldPhoneNo,
						"Email Id ", fieldEmailId,
						"Gender (M/F)", fieldGender,
						"Add Immunization (immunization, date)", fieldImmunization
						
				};
				
				int option = JOptionPane.showConfirmDialog(null, message, "Enter Medical History", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{	
					inputName = fieldName.getText();
					inputAddress = fieldAddress.getText();
					inputAge = fieldAge.getText();
					inputDOB = fieldDOB.getText();
					inputPhoneNo = fieldPhoneNo.getText();
					inputEmailId = fieldEmailId.getText();
					inputGender = fieldGender.getText();
					inputImmunization = fieldImmunization.getText();
					
					if(outp!=null) {
						if(!inputName.equals("")) {
							outp.setName(inputName);
						}
						if(!inputAddress.equals("")) {
							outp.setAddress(inputAddress);
						}
						if(!inputAddress.equals("")) {
							outp.setAge(Integer.parseInt(inputAge));
						}
						if(!inputDOB.equals("")) {
							outp.setDOB(inputAddress);
						}
						if(!inputPhoneNo.equals("")) {
							outp.setPhoneNo(inputPhoneNo);
						}
						if(!inputEmailId.equals("")) {
							outp.setEmailID(inputEmailId);
						}
						if(!inputGender.equals("")) {
							outp.setGender(inputGender.charAt(0));
						}
						if(!inputImmunization.equals("")) {
							outp.addImmunization(inputImmunization);
						}
					}
					if(inp!=null) {
						if(!inputName.equals("")) {
							inp.setName(inputName);
						}
						if(!inputAddress.equals("")) {
							inp.setAddress(inputAddress);
						}
						if(!inputAddress.equals("")) {
							inp.setAge(Integer.parseInt(inputAge));
						}
						if(!inputDOB.equals("")) {
							inp.setDOB(inputAddress);
						}
						if(!inputPhoneNo.equals("")) {
							inp.setPhoneNo(inputPhoneNo);
						}
						if(!inputEmailId.equals("")) {
							inp.setEmailID(inputEmailId);
						}
						if(!inputGender.equals("")) {
							inp.setGender(inputGender.charAt(0));
						}
						if(!inputImmunization.equals("")) {
							inp.addImmunization(inputImmunization);
						}
					}
					
				}
				
			}
			
			private void handlePatientCancel(InPatient inp, OutPatient outp) {
				if(outp.getAppointment()!=null) {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					PrintStream ps = new PrintStream(baos);
					PrintStream old = System.out;
					System.setOut(ps);
					if(outp != null) {
						outp.viewAppointment();
					}
					System.out.flush();
					System.setOut(old);
					
					JOptionPane.showMessageDialog(null, 
							"Your Appointment has been cancelled\n"
							+ outp.getAppointment().getDoctor().getName() + "\n" + outp.getAppointment().getAppointment(),
							"Appointment Cancellation", 
							JOptionPane.PLAIN_MESSAGE);
					
					outp.cancelAppointment();
					
				}
				else {
					JOptionPane.showMessageDialog(null, 
							"You do not have any appointments booked\n",
							"Error Cancelling Appointment", 
							JOptionPane.ERROR_MESSAGE);
					
				}
			}
			
			//Patient View appointment list
			private void handlePatientViewAppt(InPatient inp, OutPatient outp) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				if(outp != null) {
					outp.viewAppointment();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Appointments", 
						JOptionPane.PLAIN_MESSAGE);
			}
			
			//Patient View History
			private void handlePatientViewHistory(InPatient inp, OutPatient outp) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);

				if(inp != null) {
					inp.getHistory().setPatient(inp);
					inp.getHistory().viewHistory();
				}
				else if(outp != null) {
					outp.getHistory().setPatient(outp);
					outp.getHistory().viewHistory();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"View History", 
						JOptionPane.PLAIN_MESSAGE);
			
			}
			
			//Viewing Patient Billing Information
			private void handlePatientBilling(InPatient inp, OutPatient outp) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);

				if(inp != null) {
					inp.getBilling().printBill();
				}
				else if(outp != null) {
					outp.getBilling().printBill();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Bill", 
						JOptionPane.PLAIN_MESSAGE);
			}

			private void handlePatientExit(InPatient inp, OutPatient outp) {
				
				patientFrame.dispatchEvent(new WindowEvent(patientFrame, WindowEvent.WINDOW_CLOSING));
				if(inp != null)
				{
					//Inpatient menu
					JOptionPane.showMessageDialog(null, 
							"Patient " + inp.getName() + " has logged out successfully",
							"Log Out",
							JOptionPane.PLAIN_MESSAGE);
				}
				else if(outp != null)
				{
					//OutPatient menu
					JOptionPane.showMessageDialog(null, 
							"Patient " + outp.getName() + " has logged out successfully",
							"Log Out",
							JOptionPane.PLAIN_MESSAGE);
				}
			}

			//Main program for patient booking
			private void handlePatientBook(InPatient inp, OutPatient outp) {
				if(outp.getAppointment() == null) {
					patientBookFrame = new JFrame();
					patientBookPanel = new JPanel();
					
					buttonList = new ArrayList<JButton>();
					 
					for(Department d : h.getDepartmentList()) {
						JButton button = new JButton(d.getName());
						buttonList.add(button);
					}
					
					back = new JButton(" BACK ");	
					
					patientBookFrame.setLayout(new FlowLayout(FlowLayout.CENTER));
	
					GridLayout gridLayout = new GridLayout(10,1);
					gridLayout.setVgap(10);
					
					patientBookPanel.setLayout(gridLayout);
					
					for(JButton button : buttonList) {
						button.addActionListener(new PatientBookListener(outp));
					}
					back.addActionListener(new PatientBookListener(outp));
					patientBookPanel.add(new JLabel("<HTML><center>Welcome " + outp.getName() +
						"<BR>Choose an action from the Buttons below.</center></HTML>"));
					for(JButton button : buttonList) {
						patientBookPanel.add(button);
					}
	
					patientBookPanel.add(back);
					
					patientBookFrame.add(patientBookPanel);
					
					patientBookFrame.setSize(screen_width, screen_height);
					patientBookFrame.setVisible(true);
				}
				else {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					PrintStream ps = new PrintStream(baos);
					PrintStream old = System.out;
					System.setOut(ps);
					if(outp != null) {
						outp.viewAppointment();
					}
					
					System.out.flush();
					System.setOut(old);
					JOptionPane.showMessageDialog(null, 
							"You already have an appointment booked\n" + baos.toString(),
							"Error Booking Appointment", 
							JOptionPane.ERROR_MESSAGE);
					
				}
			}

			//Editing patient History
			private void handlePatientHistory(InPatient inp, OutPatient outp) {

				String inputFamily = null;
				String inputSurgery = null;
				String inputMedical = null;
				String inputObstretsic = null;
				
				JTextField fieldFamily = new JTextField();
				JTextField fieldSurgery = new JTextField();
				JTextField fieldMedical = new JTextField();
				JTextField fieldObstretsic = new JTextField();
				
				Object [] message = {
						"Medical History ", fieldMedical,
						"Surgical History ", fieldSurgery,
						"Family History ", fieldFamily,
						"Obstretric History ", fieldObstretsic
						
				};
				
				int option = JOptionPane.showConfirmDialog(null, message, "Enter Medical History", JOptionPane.OK_OPTION);
				if(option == JOptionPane.OK_OPTION)
				{
					if(outp != null) {
						inputSurgery = fieldSurgery.getText();
						inputFamily = fieldFamily.getText();
						inputMedical = fieldMedical.getText();
						inputObstretsic = fieldObstretsic.getText();
						if(!inputSurgery.equals("")) {
							outp.getHistory().setSurgicalHistory(inputSurgery);
						}
						if(!inputFamily.equals("")) {
							outp.getHistory().setFamilyHistory(inputFamily);
						}
						if(!inputMedical.equals("")) {
							outp.getHistory().setMedicalHistory(inputMedical);
						}
						if(!inputObstretsic.equals("")) {
							outp.getHistory().setObstetricHistory(inputObstretsic);
						}
					}
					else if(inp != null) {
						inputSurgery = fieldSurgery.getText();
						inputFamily = fieldFamily.getText();
						inputMedical = fieldMedical.getText();
						inputObstretsic = fieldObstretsic.getText();
						if(!inputSurgery.equals("")) {
							inp.getHistory().setSurgicalHistory(inputSurgery);
						}
						if(!inputFamily.equals("")) {
							inp.getHistory().setFamilyHistory(inputFamily);
						}
						if(!inputMedical.equals("")) {
							inp.getHistory().setMedicalHistory(inputMedical);
						}
						if(!inputObstretsic.equals("")) {
							inp.getHistory().setObstetricHistory(inputObstretsic);
						}
					}
				}
			}

			//view all info for patient
			private void handlePatientViewAll(InPatient inp, OutPatient outp) {

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);

				if(inp != null) {
					inp.getChart().setP(inp);
					inp.getChart().viewChart();
				}
				else if(outp != null) {
					outp.getChart().setP(outp);
					outp.getChart().viewChart();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"View Chart", 
						JOptionPane.PLAIN_MESSAGE);
			}
		}
		
		private class PatientBookListener implements ActionListener
		{
			OutPatient op = new OutPatient();
			
			public PatientBookListener(OutPatient outp) {
				this.op = outp;
			}
			
			public void actionPerformed(ActionEvent e) {
				JButton sourceCheck = (JButton)(e.getSource());
				for(JButton button : buttonList) {
					if(sourceCheck == button) {
						handleDepartmentBook(h.getDepartmentList().get(buttonList.indexOf(button)), op);
					}
					else if(sourceCheck == back) {
						handleBack();
					}
						
				}
				
			}
			
			//Choosing department
			private void handleDepartmentBook(Department d, OutPatient o) {
				patientBookFrame.dispatchEvent(new WindowEvent(patientBookFrame, WindowEvent.WINDOW_CLOSING));

				patientBookApptFrame = new JFrame();
				patientBookApptPanel = new JPanel();
				buttonList = new ArrayList<JButton>();
				int i = 0;
				for(Doctor doc : d.getDoctorList()) {
					buttonList.add(i, new JButton(doc.getName()));
					i++;
				}
				
				back = new JButton(" BACK ");	

				patientBookApptFrame.setLayout(new FlowLayout(FlowLayout.CENTER));

				GridLayout gridLayout = new GridLayout(10,1);
				gridLayout.setVgap(10);
				
				patientBookApptPanel.setLayout(gridLayout);
				
				i = 0;
				for(JButton button : buttonList) {
					button.addActionListener(new PatientBookDoctorListener(d.getDoctorList().get(i), o));
					i++;
				}
				
				back.addActionListener(new PatientBookDoctorListener(d.getDoctorList().get(0), o));
				
				patientBookApptPanel.add(new JLabel("<HTML><center>Welcome" +
					"<BR>Choose an action from the Buttons below.</center></HTML>"));
				
				for(JButton button : buttonList) {
					patientBookApptPanel.add(button);
				}
				
				patientBookApptPanel.add(back);
				
				patientBookApptFrame.add(patientBookApptPanel);
				
				patientBookApptFrame.setSize(screen_width, screen_height);
				patientBookApptFrame.setVisible(true);
			}
			
			private void handleBack() {
				patientBookFrame.dispatchEvent(new WindowEvent(patientBookFrame, WindowEvent.WINDOW_CLOSING));
			}
		}
		
		private class PatientBookDoctorListener implements ActionListener
		{
			Doctor d = new Doctor();
			OutPatient outp = new OutPatient();
			public PatientBookDoctorListener(Doctor doc, OutPatient o) {
				d = doc;
				outp = o;
			}
			
			public void actionPerformed(ActionEvent e) {
				JButton sourceCheck = (JButton)(e.getSource());
				for(JButton button : buttonList) {
					if(sourceCheck == button) {
						handleDoctorBooking(d, outp);
					}
					else if(sourceCheck == back) {
						handleBack();
					}
				}
				
			}
			
			//Booking appointment
			private void handleDoctorBooking(Doctor d, OutPatient outpatient) {
				d.generateAvailability();
				patientBookApptFrame.dispatchEvent(new WindowEvent(patientBookApptFrame, WindowEvent.WINDOW_CLOSING));
				patientBookDateFrame = new JFrame("Available Dates");
				patientBookDatePanel = new JPanel();
				buttonList = new ArrayList<JButton>();
				int i = 0;
				for(String date : d.getAvailableDates()) {
					buttonList.add(new JButton(d.getAvailableDates().get(i)));
					i++;
				}
				
				back = new JButton(" BACK ");	

				patientBookDateFrame.setLayout(new FlowLayout(FlowLayout.CENTER));

				GridLayout gridLayout = new GridLayout(10,1);
				gridLayout.setVgap(10);
				
				patientBookDatePanel.setLayout(gridLayout);
				
				i = 0;
				for(JButton button : buttonList) {
					button.addActionListener(new PatientBookDateListener(d, i, outpatient));
					i++;
				}
				
				back.addActionListener(new PatientBookDateListener(d, 0, outpatient));
				
				
				for(JButton button : buttonList) {
					patientBookDatePanel.add(button);
				}
				
				patientBookDatePanel.add(back);
				
				patientBookDateFrame.add(patientBookDatePanel);
				
				patientBookDateFrame.setSize(screen_width, screen_height);
				patientBookDateFrame.setVisible(true);
				
			}
			
			private void handleBack() {
				patientBookDateFrame.dispatchEvent(new WindowEvent(patientBookDateFrame, WindowEvent.WINDOW_CLOSING));
			}
		}
		
		private class PatientBookDateListener implements ActionListener{
			Doctor doc = new Doctor();
			int date;
			OutPatient outp = new OutPatient();
			public PatientBookDateListener(Doctor d, int date, OutPatient o) {
				doc = d;
				this.date = date;
				outp = o;
			}
			
			public void actionPerformed(ActionEvent e) {
				JButton sourceCheck = (JButton) (e.getSource());
				for(JButton button : buttonList) {
					if(sourceCheck == button) {
						handlePatientBookSlot(doc, date, outp);
					}
					else if(sourceCheck == back) {
						handleBack();
					}
				}
						
			}
			
			private void handlePatientBookSlot(Doctor d, int index, OutPatient outpatient) {
				d.generateAvailability();
				patientBookDateFrame.dispatchEvent(new WindowEvent(patientBookDateFrame, WindowEvent.WINDOW_CLOSING));
				patientBookSlotFrame = new JFrame("Available Slots");
				patientBookSlotPanel = new JPanel();
				buttonList = new ArrayList<JButton>();
				int i = 0;
				for(String slot : d.getAvailableSlots().get(index)) {
					buttonList.add(new JButton(slot));
					i++;
				}
				
				back = new JButton(" BACK ");	

				patientBookSlotFrame.setLayout(new FlowLayout(FlowLayout.CENTER));

				GridLayout gridLayout = new GridLayout(10,1);
				gridLayout.setVgap(10);
				
				patientBookSlotPanel.setLayout(gridLayout);
				
				i = 0;
				for(JButton button : buttonList) {
					button.addActionListener(new PatientBookSlotListener(d, index, i, outpatient));
					i++;
				}
				
				back.addActionListener(new PatientBookSlotListener(d, index, i, outpatient));
				
				
				for(JButton button : buttonList) {
					patientBookSlotPanel.add(button);
				}
				
				patientBookSlotPanel.add(back);
				
				patientBookSlotFrame.add(patientBookSlotPanel);
				
				patientBookSlotFrame.setSize(screen_width, screen_height);
				patientBookSlotFrame.setVisible(true);
			}
			private void handleBack() {
				patientBookDateFrame.dispatchEvent(new WindowEvent(patientBookDateFrame, WindowEvent.WINDOW_CLOSING));
			}
		}
		
		//Booking a appointment slot
		private class PatientBookSlotListener implements ActionListener{
			Doctor doctor = new Doctor();
			OutPatient outp = new OutPatient();
			int date;
			public PatientBookSlotListener(Doctor doc, int d, int s, OutPatient o) {
				doctor = doc;
				outp = o;
				date = d;
			}
			public void actionPerformed(ActionEvent e) {
				JButton sourceCheck = (JButton) (e.getSource());
				for(JButton button : buttonList) {
					if(sourceCheck == button) {
						handlePatientBookSlot(doctor, outp, date, buttonList.indexOf(button));
					}
					else if(sourceCheck == back) {
						handleBack();
					}
				}
						
			}
			private void handlePatientBookSlot(Doctor doctor, OutPatient outpatient, int date_index, int slot_index) {
				outpatient.bookAppointment(doctor, date_index, slot_index);
				JOptionPane.showMessageDialog(null, 
						"Your appointment has been booked!",
						"Success Booking Appointment booked", 
						JOptionPane.PLAIN_MESSAGE);
				patientBookSlotFrame.dispatchEvent(new WindowEvent(patientBookSlotFrame, WindowEvent.WINDOW_CLOSING));
			}
			private void handleBack() {
				patientBookSlotFrame.dispatchEvent(new WindowEvent(patientBookSlotFrame, WindowEvent.WINDOW_CLOSING));
			}
		}
		private class DoctorListener implements ActionListener
		{
			Doctor d = new Doctor();
			
			public DoctorListener(Doctor doctor)
			{
				this.d = doctor;
			}
			
			public void actionPerformed(ActionEvent e)
			{
				JButton source = (JButton)(e.getSource());
				
				if(source.equals(doctorAllPatients))
					handleDoctorAllPatients(d);
				else if(source.equals(doctorViewSchedule))
					handleDoctorViewSchedule(d);
				else if(source.equals(doctorCancel))
					handleDoctorCancel(d);
				else if(source.equals(doctorProcedure))
					handleDoctorProcedure(d);
				else if(source.equals(doctorViewChart))
					handleDoctorViewChart(d);
				else if(source.equals(doctorEditChart))
					handleDoctorEditChart(d);
				else if(source.equals(doctorExit))
					handleDoctorExit(d);

			}

			private void handleDoctorExit(Doctor d) {

				doctorFrame.dispatchEvent(new WindowEvent(doctorFrame, WindowEvent.WINDOW_CLOSING));
				JOptionPane.showMessageDialog(null, 
						"Doctor " + d.getName() + " has logged out successfully",
						"Log Out",
						JOptionPane.PLAIN_MESSAGE);
			}
			
			//View Doctor's schedule
			private void handleDoctorViewSchedule(Doctor d) {
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				if(d != null) {
					d.printSchedule();
				}
				
				System.out.flush();
				System.setOut(old);
				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Appointments", 
						JOptionPane.PLAIN_MESSAGE);
			}

			//View all patients
			private void handleDoctorAllPatients(Doctor d) {

				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(Patient p: d.getPatientList())
				{
					System.out.println(p.getName());
				}
				System.out.flush();
				System.setOut(old);

				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Patients under " + d.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
			}

			//Request cahnge of schedule from admin
			private void handleDoctorCancel(Doctor d) {
				
				doctorCancelFrame = new JFrame();
				doctorCancelPanel = new JPanel();
				buttonList = new ArrayList<JButton>();
				int i = 0;
				for(String appointment : d.getStringSchedule()) {
					System.out.println(appointment);
					buttonList.add(new JButton(appointment));
				}
				
				back = new JButton(" BACK ");	

				doctorCancelFrame.setLayout(new FlowLayout(FlowLayout.CENTER));

				GridLayout gridLayout = new GridLayout(10,1);
				gridLayout.setVgap(10);
				
				doctorCancelPanel.setLayout(gridLayout);
				
				i = 0;
				for(JButton button : buttonList) {
					button.addActionListener(new DoctorCancelListener(d));
					i++;
				}
				
				back.addActionListener(new DoctorCancelListener(d));
				
				
				for(JButton button : buttonList) {
					doctorCancelPanel.add(button);
				}
				
				doctorCancelPanel.add(back);
				
				doctorCancelFrame.add(doctorCancelPanel);
				
				doctorCancelFrame.setSize(screen_width, screen_height);
				doctorCancelFrame.setVisible(true);
				
			}
			
			//Request lab procedure for a patient
			private void handleDoctorProcedure(Doctor d) {

				int inputIndex = 0;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < d.getPatientList().size(); i++)
				{
					System.out.println((i+1) + ") " + d.getPatientList().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Choose from Patients under " + d.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					inputIndex = inputIndex - 1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						LabRequestForm lfr = new LabRequestForm();
						lfr.setPatient(d.getPatientList().get(inputIndex));
						lfr.setDoctor(d);
						String inputProcedure;
						inputProcedure = JOptionPane.showInputDialog(null, 
								"Enter Lab Procedure",
								"Lab Procedure Form", 
								JOptionPane.PLAIN_MESSAGE);
						lfr.setLabProcedure(inputProcedure);
						if(lfr.getLabProcedure().trim().equals(""))
						{
							JOptionPane.showMessageDialog(null,
									"Please enter fields correctly",
									"Error",
									JOptionPane.ERROR_MESSAGE);
						}
						else 
						{
							JOptionPane.showMessageDialog(null, 
									"Lab Procedure " + lfr.getLabProcedure() + " for patient " + lfr.getPatient().getName() + " is requested",
									"Success", 
									JOptionPane.PLAIN_MESSAGE);
							h.getAdmin().addToListOfLabRequestForms(lfr);
						}
					}
				}
			}

			//View Chart for doctor
			private void handleDoctorViewChart(Doctor d) {

				int inputIndex = -1;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < d.getPatientList().size(); i++)
				{
					System.out.println((i+1) + ") " + d.getPatientList().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Choose from Patients under " + d.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText()) - 1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
						PrintStream ps2 = new PrintStream(baos2);
						PrintStream old2 = System.out;
						System.setOut(ps2);
						
						d.getPatientList().get(inputIndex).getChart().viewChart();
						System.out.flush();
						System.setOut(old2);
						JOptionPane.showMessageDialog(null, 
								baos2.toString(),
								"View Chart", 
								JOptionPane.PLAIN_MESSAGE);
					}
				}
			}

			//Edit chart for doctor
			private void handleDoctorEditChart(Doctor d) {

				int inputIndex = -1;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < d.getPatientList().size(); i++)
				{
					System.out.println((i+1) + ") " + d.getPatientList().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Choose from Patients under " + d.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					inputIndex -= 1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						String currentDiagnosis = null;
						String currentMedication = null;
						String note = null;

						JTextField fieldCurrentDiagnosis = new JTextField();
						JTextField fieldCurrentMedication = new JTextField();
						JTextField fieldNote = new JTextField();

						Object [] message_chosen = {
								"Current Diagnosis ", fieldCurrentDiagnosis,
								"Current Medication ", fieldCurrentMedication,
								"Add Note ", fieldNote
								
						};
						
						int option_chosen = JOptionPane.showConfirmDialog(null, message_chosen, "Edit Patient Chart", JOptionPane.OK_OPTION);
						if(option_chosen == JOptionPane.OK_OPTION)
						{	
							currentDiagnosis = fieldCurrentDiagnosis.getText();
							currentMedication = fieldCurrentMedication.getText();
							note = fieldNote.getText();
							
							if(!currentDiagnosis.equals("")) {
								d.getPatientList().get(inputIndex).getChart().setCurrentDiagnosis(currentDiagnosis);
							}
							if(!currentMedication.equals("")) {
								d.getPatientList().get(inputIndex).getChart().setCurrentMedication(currentMedication);
							}
							if(!note.equals("")) {
								d.getPatientList().get(inputIndex).getChart().addNotes(note);
							}
					
						}
					}
				}
				
					
			}

			
		}
		
		private class DoctorCancelListener implements ActionListener
		{
			Doctor d = new Doctor();
			boolean possible;
			public DoctorCancelListener(Doctor doc) {
				d = doc;
			}
			
			public void actionPerformed(ActionEvent e) {
				JButton sourceCheck = (JButton)(e.getSource());
				for(JButton button : buttonList) {
					if(sourceCheck == button) {
						handleDoctorCancel(d, buttonList.indexOf(button));
					}
					else if(sourceCheck == back) {
						handleBack();
					}
						
				}
				
			}
			
			//Cancelation of appointment request
			private void handleDoctorCancel(Doctor d, int index) {
				possible = d.cancelRequest(index);
				if(possible) {
					doctorCancelFrame.dispatchEvent(new WindowEvent(doctorCancelFrame, WindowEvent.WINDOW_CLOSING));
					JOptionPane.showMessageDialog(null, 
							"Your request will be processed in 1-2 business days",
							"Cancel Request Success",
							JOptionPane.PLAIN_MESSAGE);
				}
				else
				{
					doctorCancelFrame.dispatchEvent(new WindowEvent(doctorCancelFrame, WindowEvent.WINDOW_CLOSING));
					JOptionPane.showMessageDialog(null, 
							"You can only cancel an appointment 48 hours prior to the date",
							"Cancel Request Declined",
							JOptionPane.PLAIN_MESSAGE);
					
				}
			}
			
			private void handleBack() {
				doctorCancelFrame.dispatchEvent(new WindowEvent(doctorCancelFrame, WindowEvent.WINDOW_CLOSING));
			}
			
		}
			
		private class NurseListener implements ActionListener
		{
			Nurse n = new Nurse();
			
			public NurseListener(Nurse nurse)
			{
				this.n = nurse;
			}
			
			public void actionPerformed(ActionEvent e)
			{
				JButton source = (JButton)(e.getSource());
				
				if(source.equals(nurseAllPatients))
					handleNurseAllPatients(n);
				else if(source.equals(nurseViewChart))
					handleNurseViewChart(n);
				else if(source.equals(nurseEditChart))
					handleNurseEditChart(n);
				else if(source.equals(nurseNew))
					handleNurseNew(n);
				else if(source.equals(nurseExit))
					handleNurseExit(n);

			}

			//Exit menu
			private void handleNurseExit(Nurse n) {

				nurseFrame.dispatchEvent(new WindowEvent(nurseFrame, WindowEvent.WINDOW_CLOSING));
				JOptionPane.showMessageDialog(null, 
						"Nurse " + n.getName() + " has logged out successfully",
						"Log Out",
						JOptionPane.PLAIN_MESSAGE);
			}

			//Patient edit chart
			private void handleNurseEditChart(Nurse n) {

				int inputIndex = -1;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < n.getListOfPatients().size(); i++)
				{
					System.out.println((i+1) + ") " + n.getListOfPatients().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Choose from Patients under " + n.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					inputIndex -= 1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						String currentDiagnosis = null;
						String currentMedication = null;
						String note = null;

						JTextField fieldCurrentDiagnosis = new JTextField();
						JTextField fieldCurrentMedication = new JTextField();
						JTextField fieldNote = new JTextField();

						Object [] message_chosen = {
								"Current Diagnosis ", fieldCurrentDiagnosis,
								"Current Medication ", fieldCurrentMedication,
								"Add Note ", fieldNote
								
						};
						
						int option_chosen = JOptionPane.showConfirmDialog(null, message_chosen, "Edit Patient Chart", JOptionPane.OK_OPTION);
						if(option_chosen == JOptionPane.OK_OPTION)
						{	
							currentDiagnosis = fieldCurrentDiagnosis.getText();
							currentMedication = fieldCurrentMedication.getText();
							note = fieldNote.getText();
							
							if(!currentDiagnosis.equals("")) {
								n.getListOfPatients().get(inputIndex).getChart().setCurrentDiagnosis(currentDiagnosis);
							}
							if(!currentMedication.equals("")) {
								n.getListOfPatients().get(inputIndex).getChart().setCurrentMedication(currentMedication);
							}
							if(!note.equals("")) {
								n.getListOfPatients().get(inputIndex).getChart().addNotes(note);
							}
					
						}
					}
				}
				
					

			}

			
			//View patient chart
			private void handleNurseViewChart(Nurse n) {
				
				int inputIndex = -1;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < n.getListOfPatients().size(); i++)
				{
					System.out.println((i+1) + ") " + n.getListOfPatients().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Choose from Patients under " + n.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText())-1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
						PrintStream ps2 = new PrintStream(baos2);
						PrintStream old2 = System.out;
						System.setOut(ps2);
						n.getListOfPatients().get(inputIndex).getChart().viewChart();
						System.out.flush();
						System.setOut(old2);
						JOptionPane.showMessageDialog(null, 
								baos2.toString(),
								"View Chart", 
								JOptionPane.PLAIN_MESSAGE);
					}
				}
			}

			//View list of patients
			private void handleNurseAllPatients(Nurse n) {
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(InPatient inp: n.getListOfPatients())
				{
					System.out.println(inp.getName());
				}
				System.out.flush();
				System.setOut(old);

				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Patients under " + n.getName() + "'s care.", 
						JOptionPane.PLAIN_MESSAGE);
			}
			
			//Setting up new patient
			private void handleNurseNew(Nurse n) 
			{

				InPatient inp = new InPatient();
				Department d = new Department();
				Doctor dr = new Doctor();
			
				String Name;
				String DOB;
				int age;
				String address;
				char gender;
				String phoneNo;
				String emailID;
				String password;
				
				int choice;
				
				JTextField fieldName = new JTextField();
				JTextField fieldDOB = new JTextField();
				JTextField fieldAge = new JTextField();
				JTextField fieldAddress = new JTextField();
				JTextField fieldGender = new JTextField();
				JTextField fieldPhoneNo = new JTextField();
				JTextField fieldEmail = new JTextField();
				JTextField fieldPassword = new JTextField();
				
				JTextField fieldIndex = new JTextField();
				int inputIndex = -1;
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(int i = 0; i < h.getDepartmentList().size(); i++)
				{
					System.out.println((i+1) + ") " + h.getDepartmentList().get(i).getName());
				}
				System.out.flush();
				System.setOut(old);
	
				Object [] message1 = {
						baos.toString(), "Enter index of Department", fieldIndex
				};
				
				choice = JOptionPane.showConfirmDialog(null, 
						message1,
						"Choose from the Departments", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(choice == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText())-1;
					//if entry is blank
					if((inputIndex == -1) || (inputIndex >= h.getDepartmentList().size()))  
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						d = h.getDepartmentList().get(inputIndex);
						ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
						PrintStream ps2 = new PrintStream(baos2);
						PrintStream old2 = System.out;
						System.setOut(ps2);
						for(int j = 0; j < d.getDoctorList().size(); j++)
						{
							System.out.println((j+1) + ") " + d.getDoctorList().get(j).getName());
						}
						System.out.flush();
						System.setOut(old2);
						
						Object [] message2 = {
								baos2.toString(), "Enter index of Doctor", fieldIndex
						};
						
						choice = JOptionPane.showConfirmDialog(null, 
								message2,
								"Choose from the Doctors", 
								JOptionPane.PLAIN_MESSAGE);
						//If "ok" is clicked
						if(choice == JOptionPane.OK_OPTION)
						{
							inputIndex = Integer.parseInt(fieldIndex.getText()) - 1;
							//if entry is blank
							if((inputIndex == -1) || (inputIndex >= d.getDoctorList().size()))
							{
								JOptionPane.showMessageDialog(null,
										"Please enter fields correctly",
										"Error",
										JOptionPane.ERROR_MESSAGE);
							}
							else
							{
								dr = d.getDoctorList().get(inputIndex);
								
								Object [] message3 = {
										"Fields Mmarked with (*) cannot be left blank",
										"*Name:", fieldName,
										"DOB (MMDDYYYY)", fieldDOB,
										"Age: ", fieldAge,
										"Address: ", fieldAddress,
										"Gender: ", fieldGender,
										"Email: ", fieldEmail,
										"PhoneNo: ", fieldPhoneNo,
										"*Password:", fieldPassword
								};
								
								choice = JOptionPane.showConfirmDialog(null, message3, "New Patient Info", JOptionPane.OK_OPTION);
								if(choice == JOptionPane.OK_OPTION)
								{
									Name = fieldName.getText();
									password = fieldPassword.getText();
									
									if((Name.trim().equals("")) || (password.trim().equals("")))
									{
										JOptionPane.showMessageDialog(null,
												"Please enter fields correctly",
												"Error",
												JOptionPane.ERROR_MESSAGE);
									}
									else
									{
										DOB = fieldDOB.getText();
										address = fieldAddress.getText();
										
										if(!fieldGender.getText().trim().equals("")) {
											gender = fieldGender.getText().charAt(0);
											inp.setGender(gender);
										}
									
										emailID = fieldEmail.getText();
										phoneNo = fieldPhoneNo.getText();
										h.addToInPatientList(inp);
										h.addToPatientList(inp);
										inp.setH(h);				
										inp.setName(Name);
										inp.setDOB(DOB);
										if(!fieldAge.getText().trim().equals("")) {
											age = Integer.parseInt(fieldAge.getText());
											inp.setAge(age);
										}
										inp.setAddress(address);
										
										inp.setEmailID(emailID);
										inp.setPhoneNo(phoneNo);
										inp.setPassword(password);
										Billing b = new Billing();
										inp.setBill(b);
										Chart c = new Chart();
										inp.setChart(c);
										History history = new History();
										inp.setHistory(history);
									}
								}
							}
						}
					}
				}
			}
		}
		
		private class AdminListener implements ActionListener
		{
			Admin a = new Admin();
			
			public AdminListener(Admin admin)
			{
				this.a = h.getAdmin();
			}
			
			public void actionPerformed(ActionEvent e)
			{
				JButton source = (JButton)(e.getSource());
				
				if(source.equals(adminAllPatients))
					handleAdminAllPatients(a);
				else if(source.equals(adminApprove))
					handleAdminApprove(a);
				else if(source.equals(adminBilling))
					handleAdminBilling(a);
				else if(source.equals(adminProcedure))
					handleProcedure(a);
				else if(source.equals(adminExit))
					handleAdminExit(a);

			}

			//Exit admin menu
			private void handleAdminExit(Admin a) {

				adminFrame.dispatchEvent(new WindowEvent(adminFrame, WindowEvent.WINDOW_CLOSING));
				JOptionPane.showMessageDialog(null, 
						"Admin " + a.getName() + " has logged out successfully",
						"Log Out",
						JOptionPane.PLAIN_MESSAGE);
			}

			//View all patients
			private void handleAdminAllPatients(Admin a) {
			
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(Patient p: h.getPatientList())
				{
					System.out.println(p.getName());
				}
				System.out.flush();
				System.setOut(old);

				JOptionPane.showMessageDialog(null, 
						baos.toString(),
						"Patients under " + a.getName(), 
						JOptionPane.PLAIN_MESSAGE);
				
			}

			
			//Function to approve change in schedule for doctor
			private void handleProcedure(Admin a) {
			
				int inputIndex = 0;
				int i;
				JTextField fieldIndex = new JTextField();
				//a.viewForm(a.getListOfProcedureForms().get(0));
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < a.getListOfProcedureForms().size(); i++)
				{
					System.out.println((i + 1) + ")");
					a.viewForm(a.getListOfProcedureForms().get(i));
					
				}
				
				System.out.flush();
				System.setOut(old);
				System.out.println("BLAH " + a.getListOfProcedureForms().size());
				Object [] message = {
						baos.toString(), "Enter index of Form", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Ok to Approve or Cancel to reject", 
						JOptionPane.OK_CANCEL_OPTION);
				
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					//if entry is blank
					inputIndex = inputIndex - 1;
					System.out.println("BLAH 2 " + a.getListOfProcedureForms().size() + " " + inputIndex);
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						JOptionPane.showMessageDialog(null,
								"Approved Form Successfully for " + a.getListOfProcedureForms().get(inputIndex).getDoctor().getName(),
								"Error",
								JOptionPane.ERROR_MESSAGE);
						a.approveProcedure(a.getListOfProcedureForms().get(inputIndex));
						
					}
				}
				
				else if(option == JOptionPane.CANCEL_OPTION) {
					inputIndex = Integer.parseInt(fieldIndex.getText());
					//if entry is blank
					inputIndex = inputIndex - 1;
					System.out.println("BLAH 3 " + a.getListOfProcedureForms().size() + " " + inputIndex);
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						JOptionPane.showMessageDialog(null,
								"Discarded Form Successfully for " + a.getListOfProcedureForms().get(inputIndex).getDoctor().getName(),
								"Declined Request",
								JOptionPane.PLAIN_MESSAGE);
						
						a.getListOfProcedureForms().remove(inputIndex);
					
					}
				}
					
				
			}

			//Function to approve lab procedure
			private void handleAdminApprove(Admin a) {
				int inputIndex = 0;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < a.getListOfLabRequestForms().size(); i++)
				{
					System.out.println((i+1) + ") " + a.getListOfLabRequestForms().get(i).getDoctor().getName());
					// added a new function getListOfLabRequestForms in class Admin
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Form", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Ok to Approve or Cancel to reject", 
						JOptionPane.OK_CANCEL_OPTION);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					inputIndex = inputIndex - 1;
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						//a.approveLabRequest(a.getListOfLabRequestForms().get(inputIndex));
						//	a.getListOfLabRequestForms().get(inputIndex).getPatient().getBilling().addtoTotal(a.getListOfLabRequestForms().get(inputIndex).getCost());
						// added a new function add to total in class Billing
						// used 10 dollars a charge for a Lab 
						JOptionPane.showMessageDialog(null,
								"Approved Form Successfully for " + a.getListOfLabRequestForms().get(inputIndex).getDoctor().getName(),
								"Error",
								JOptionPane.PLAIN_MESSAGE);
						 a.approveLabRequest(a.getListOfLabRequestForms().get(inputIndex));
					}
				}
				else if(option == JOptionPane.CANCEL_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					//if entry is blank
					inputIndex = inputIndex - 1;
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						JOptionPane.showMessageDialog(null,
								"Discarded Form Successfully for " + a.getListOfLabRequestForms().get(inputIndex).getDoctor().getName(),
								"Declined Request",
								JOptionPane.PLAIN_MESSAGE);
					}
				}
			}

			//Function for admin to view billing
			private void handleAdminBilling(Admin a) {
				int inputIndex = -1;
				int i;
				JTextField fieldIndex = new JTextField();
				
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				PrintStream ps = new PrintStream(baos);
				PrintStream old = System.out;
				System.setOut(ps);
				for(i = 0; i < h.getPatientList().size(); i++)
				{
					System.out.println(i + ") " + h.getPatientList().get(i).getName());
					// added a new function getListOfLabRequestForms in class Admin
				}
				System.out.flush();
				System.setOut(old);
				
				Object [] message = {
						baos.toString(), "Enter index of Patient to see Billing Information", fieldIndex
				};
				
				int option = JOptionPane.showConfirmDialog(null, 
						message,
						"Ok to see Billing", 
						JOptionPane.PLAIN_MESSAGE);
				//If "ok" is clicked
				if(option == JOptionPane.OK_OPTION)
				{
					inputIndex = Integer.parseInt(fieldIndex.getText());
					//if entry is blank
					if(inputIndex == -1)
					{
						JOptionPane.showMessageDialog(null,
								"Please enter fields correctly",
								"Error",
								JOptionPane.ERROR_MESSAGE);
					}
					else
					{	
						ByteArrayOutputStream baos2 = new ByteArrayOutputStream();
						PrintStream ps2 = new PrintStream(baos2);
						PrintStream old2 = System.out;
						System.setOut(ps2);
						h.getPatientList().get(inputIndex).getBilling().printBill();
						System.out.flush();
						System.setOut(old2);
						JOptionPane.showMessageDialog(null, 
								baos2.toString(),
								"View Bill", 
								JOptionPane.PLAIN_MESSAGE);
						
						}
					
				
			}
				
			}
		}
}
