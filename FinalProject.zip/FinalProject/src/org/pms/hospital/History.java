package org.pms.hospital;

import java.util.*;

import org.pms.people.*;

public class History {
	
	Patient p;
	private String familyHistory;
	private ArrayList<String> immunizationRecords = new ArrayList<String>();
	private String surgicalHistory;
	private String obstetricHistory;
	private String medicalHistory;
	
	public History() {
		Patient p;
		familyHistory = null;
		immunizationRecords = new ArrayList<String>();
		surgicalHistory = null;
		obstetricHistory = null;
		medicalHistory = null;
	}

	public Patient getPatient() {
		return p;
	}

	public void setPatient(Patient p) {
		this.p = p;
	}

	public String getFamilyHistory() {
		return familyHistory;
	}

	public void setFamilyHistory(String familyHistory) {
		this.familyHistory = familyHistory;
	}

	public ArrayList<String> getImmunizationRecords() {
		return immunizationRecords;
	}

	public void setImmunizationRecords(ArrayList<String> immunizationRecords) {
		this.immunizationRecords = immunizationRecords;
	}

	public String getSurgicalHistory() {
		return surgicalHistory;
	}

	public void setSurgicalHistory(String surgicalHistory) {
		this.surgicalHistory = surgicalHistory;
	}

	public String getObstetricHistory() {
		return obstetricHistory;
	}

	public void setObstetricHistory(String obstetricHistory) {
		this.obstetricHistory = obstetricHistory;
	}

	public String getMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}
	
	public void addToImmunizationHistory(String immunization) {
		this.immunizationRecords.add(immunization);
	}
	
	
	//Function to view History
	public void viewHistory() {
		System.out.printf("%200.200s%n", "\n********************************************** PATIENT HISTORY ***********************************************\n");
		System.out.println("Family History: " + familyHistory);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Surgical History: " + surgicalHistory);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Medical History: " + medicalHistory);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Obstetric History: " + obstetricHistory);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
	}

}
