package org.pms.hospital;

import java.util.ArrayList;

public class Billing {
	
	private ArrayList<String> treatmentList = new ArrayList<String>();
	private ArrayList<Double> charge = new ArrayList<Double>();
	private double total;
	private final double TAX = 7.0;
	
	public Billing() {
		treatmentList = new ArrayList<String>();
		charge = new ArrayList<Double>();
		total = 0.0;
	}
	
	public ArrayList<String> getTreatmentList() {
		return treatmentList;
	}

	public ArrayList<Double> getCharge() {
		return charge;
	}

	//Function to calculate total
	public void calculateTotal() {
		for(double charge: this.charge) {
			this.total += charge;
		}
		total += (TAX/100) * total;
	}  
	
	//Function to print out the bill
	public void printBill() {
		System.out.printf("%-20s %8s\n","Treatment","Charge");
		System.out.println("---------------------------");
		for(int i = 0; i < treatmentList.size(); ++i) {
			System.out.printf("%-20s %8.2f\n", treatmentList.get(i), charge.get(i)); 
		}
		System.out.println("Tax (AZ):	7%");
		System.out.println("---------------------------");
		
		calculateTotal();
		System.out.println("TOTAL: " + this.total);
		
	}

}
