package org.pms.hospital;
import java.util.*;

public class Lab {
	
	//Fields
	private String name;
	private ArrayList<LabRequestForm> listOfLabRequestForms = new ArrayList<LabRequestForm>();
	private LabReport labreport;
	Scanner sc = new Scanner(System.in);
	
	//Constructor
	public Lab() {
		this.name = "unknown";
	}
	
	//Getters and Setters
	public String getName() {
		return this.name;
		
	}
	public void setName(String s) {
		this.name = s;
	}
	
	public void processLabRequest() {
		if(this.listOfLabRequestForms.size() > 0) {
			this.listOfLabRequestForms.get(0).setProcessed(true);	
			this.listOfLabRequestForms.get(0).getPatient().getChart().addLabReport(labreport);
			this.listOfLabRequestForms.remove(0);
		}
	}
	//Methods

	
	public ArrayList<LabRequestForm> getListOfLabRequestForms() {
		return listOfLabRequestForms;
	}

	public void setListOfLabRequestForms(ArrayList<LabRequestForm> listOfLabRequestForms) {
		this.listOfLabRequestForms = listOfLabRequestForms;
	}
	
	public void addToListOfLabRequestForms(LabRequestForm form) {
		this.listOfLabRequestForms.add(form);
		LabReport lr = new LabReport(); 
		lr.setPatient(form.getPatient());
		lr.addToTests(form.getLabProcedure());
		lr.setCost(100.0);
		form.getPatient().getBilling().getTreatmentList().add(form.getLabProcedure());
		form.getPatient().getBilling().getCharge().add(lr.getCost());
		form.getPatient().addToListOfLabReports(lr);
	}
}
