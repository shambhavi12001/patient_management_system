package org.pms.hospital;

import java.time.Instant;
import java.util.*;

//import project.people.Admin;
import org.pms.people.*;
public class Hospital {
	
	//Fields
	private ArrayList<Department> departmentList;
	private Admin admin;
	private ArrayList<Doctor> doctorList;
	private ArrayList<OutPatient> outPatientList;
	private ArrayList<InPatient> inPatientList;
	private ArrayList<Patient> patientList;
	private ArrayList<Nurse> nurseList;
	private Patient p;
	private Doctor d;
	private Nurse n; 
	
	private String username;
	private String password;
	
	Scanner sc = new Scanner(System.in);
	
	//Constructor
	public Hospital() {
		this.departmentList = new ArrayList<Department>();
		this.doctorList = new ArrayList<Doctor>();
		this.outPatientList = new ArrayList<OutPatient>();
		this.inPatientList = new ArrayList<InPatient>();
		this.patientList = new ArrayList<Patient>();
		this.nurseList = new ArrayList<Nurse>(); 	
	}

	//Getters and Setters
	public ArrayList<Department> getDepartmentList() {
		return departmentList;
	}

	public void addDepartmentList(Department department) {
		this.departmentList.add(department);
		department.setH(this);
	}

	public void addToInPatientList(InPatient patient) {
		this.inPatientList.add(patient);
		patient.setH(this);	
	}
	
	public void addToOutPatientList(OutPatient patient) {
		this.outPatientList.add(patient);
		patient.setH(this);
		
	}
	
	public ArrayList<Doctor> getDoctorList() {
		return doctorList;
	}
	
	
	public ArrayList<Nurse> getNurseList() {
		return nurseList;
	}
	
	public void addToNurseList(Nurse n) {
		nurseList.add(n);
		n.setH(this);
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin a) {
		this.admin = a;
	}
	
	public void addToDoctorList(Doctor d) {
		this.doctorList.add(d);
		d.setH(this);
	}
	
	public void addToPatientList(Patient p) {
		this.patientList.add(p);
		//this.inPatientList.add(p);
		p.setH(this);
	}
	
	public ArrayList<Patient> getPatientList() {
		return patientList;
	}
	

	//Checks whether there is a admin by username
	public Admin ContainsAdmin(String inputUserName) {
        // TODO Auto-generated method stub
        if(this.admin.getUsername().compareTo(inputUserName) == 0)
            return this.admin;
        return null;
    }

	//Checks whether there is a nurse by username
    public Nurse ContainsNurse(String inputUserName) {
        // TODO Auto-generated method stub
        for(Nurse n: this.nurseList)
        {
            if(n.getUsername().compareTo(inputUserName) == 0)
                return n;
        }
        return null;
    }

  //Checks whether there is a doctor by username
    public Doctor ContainsDoctor(String inputUserName) {
        // TODO Auto-generated method stub
        for(Doctor d: this.doctorList)
        {
            System.out.println(d.getName()+ d.getUsername() + d.getPassword());
            if(inputUserName.compareTo(d.getUsername()) == 0)
                return d;
        }
        return null;
    }

  //Checks whether there is a OutPatient by name
    public OutPatient ContainsOutPatient(String inputName) {
        // TODO Auto-generated method stub
        for(OutPatient outp: this.outPatientList)
        {
            System.out.println(outp.getName());
            if(outp.getName().compareTo(inputName) == 0)
                return outp;
        }
        return null;
    }

  //Checks whether there is a InPatient by name
    public InPatient ContainsInPatient(String inputName) {
        // TODO Auto-generated method stub
        for(InPatient inp: this.inPatientList)
        {
            if(inp.getName().compareTo(inputName) == 0)
                return inp;
        }
        return null;
    }
	
}
