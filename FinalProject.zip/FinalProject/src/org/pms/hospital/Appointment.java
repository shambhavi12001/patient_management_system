package org.pms.hospital;
import org.pms.people.*;
import java.util.*;


public class Appointment {
	
	private Doctor d;
	private OutPatient p;
	private String appt;
	public Doctor getDoctor() {
		return d;
	}
	public void setDoctor(Doctor d) {
		this.d = d;
	}
	public OutPatient getPatient() {
		return p;
	}
	public void setPatient(OutPatient p) {
		this.p = p;
	}
	public String getAppointment() {
		return appt;
	}
	public void setAppointment(String appt) {
		this.appt = appt;
	}
	
	public int getHour(String date) {
		int hour = Integer.parseInt(appt.substring(16, 18));
		if(hour == 12) {
			return 0;
		}
		return hour;
	}
	public int getMinute(String date) {
		return Integer.parseInt(appt.substring(19, 21));
	}
	
	public int getDate(String date) {
		return Integer.parseInt(appt.substring(3, 5));
	}
	
	public int getMonth(String date) {
		return Integer.parseInt(appt.substring(0, 2)) - 1;
	}
	public int getYear(String date) {
		//System.out.println(Integer.parseInt(appt.substring(6, 10)));
		return Integer.parseInt(appt.substring(6, 10));	
	}
	
	public int getAM_PM(String date) {
		if(appt.substring(22, 24).equals("AM")) {
			return Calendar.AM;
		}
		return Calendar.PM;

	}
	
	public Date getCurrTime() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}
	public Date getOriginalDate(String date) {
		Calendar calendar = Calendar.getInstance();
		calendar.set(getYear(date), getMonth(date), getDate(date), getHour(date), getMinute(date), 0);
		calendar.set(Calendar.HOUR, getHour(date));
		calendar.set(Calendar.AM_PM, getAM_PM(date));
		return calendar.getTime();
	}
	
	public long convertDate() {
		long conversion = Integer.parseInt(appt.substring(0, 2)) * 1000000 + Integer.parseInt(appt.substring(3, 5)) * 10000 +
				Integer.parseInt(appt.substring(16, 18)) * 100 + Integer.parseInt(appt.substring(19, 21));
		return conversion;
	}
	
	
	
}
