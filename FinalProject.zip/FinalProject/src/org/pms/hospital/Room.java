package org.pms.hospital;

import org.pms.people.*;

public class Room {
	
	//Fields
	private int roomNo;
	private InPatient  patient;
	
	//Constructor
	public Room() {
		this.roomNo = 0;
		this.patient = null;
	}
	
	//Getters and Setters
	public int getRoomNo() {
		return this.roomNo;
	}
	public void setName(int i) {
		this.roomNo = i;
	}

	public InPatient getPatient() {
		return patient;
	}

	public void setPatient(InPatient patient) {
		this.patient = patient;
		patient.setRoom(this);
	}
	
	//Methods
}
