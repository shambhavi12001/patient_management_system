package org.pms.hospital;

import java.util.*;

import org.pms.people.*;

public class Chart {
	private Patient p;
	//private ArrayList<String> ImmunizationHistory = new ArrayList<String>();
	private String currentDiagnosis;
	private String currentMedication;
	private ArrayList<String> medication = new ArrayList<String>();
	Scanner sc = new Scanner(System.in);
	//private String surgicalHistory;
	//private String obstetricHistory;
	private ArrayList<String> notes = new ArrayList<String>();
	private ArrayList<LabReport> labreports = new ArrayList<LabReport>();
	//private String medicalHistory;
	//private ArrayList<LabReport> = new ArrayList<LabReport>();
	
	public Chart() {
		this.currentDiagnosis = null;
		this.currentMedication = null;
		this.medication = new ArrayList<String>();
		this.notes = new ArrayList<String>();
	}
	
	
	public Patient getP() {
		return p;
	}


	public void setP(Patient p) {
		this.p = p;
	}


	public String getCurrentDiagnosis() {
		return currentDiagnosis;
	}


	public void setCurrentDiagnosis(String currentDiagnosis) {
		this.currentDiagnosis = currentDiagnosis;
	}


	public String getCurrentMedication() {
		return currentMedication;
	}


	public void setCurrentMedication(String currentMedication) {
		this.currentMedication = currentMedication;
	}


	public ArrayList<String> getMedication() {
		return medication;
	}


	public void setMedication(ArrayList<String> medication) {
		this.medication = medication;
	}


	public Scanner getSc() {
		return sc;
	}


	public void setSc(Scanner sc) {
		this.sc = sc;
	}


	public ArrayList<String> getNotes() {
		return notes;
	}


	public void setNotes(ArrayList<String> notes) {
		this.notes = notes;
	}


	public ArrayList<LabReport> getLabreports() {
		return labreports;
	}


	public void setLabreports(ArrayList<LabReport> labreports) {
		this.labreports = labreports;
	}

	public void addLabReport(LabReport labreport) {
		this.labreports.add(labreport);
	}
	
	public void editDiagnosis() {
		System.out.println("Enter diagnosis: ");
		currentDiagnosis = sc.nextLine();
	}
	public void editMedication() {
		System.out.println("Enter medication: ");
		//Calendar calendar = Calendar.getInstance();
		medication.add(currentMedication);
		currentMedication = sc.nextLine();
	}
	public void addNotes(String note)
	{
		notes.add(note);
		
	}
	
	//Function to view the chart
	public void viewChart() {
		System.out.printf("%200.200s%n", "\n********************************************** PATIENT CHART ***********************************************\n");
		System.out.println("Name: " + p.getName() + "\n");
		System.out.println("Age:" + p.getAge() + "\n");
		System.out.println("Gender: " + p.getGender() + "\n");
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Current Diagnosis: ");
		int i = 0;
		for(i = 0; currentDiagnosis.length()-i >= 100; i += 100) {
			System.out.println(currentDiagnosis.substring(i, 100));
		}
		System.out.println(currentDiagnosis.substring(i, currentDiagnosis.length()));
		
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Current Medication: " + currentMedication);
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Medication Prescribed: ");
		for(String medicine: this.medication) {
			System.out.println((this.medication.indexOf(medicine) + 1) + ". " + medicine);
		}
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		System.out.println("Notes: ");
		for(String note: this.notes) {
			System.out.println(note);
		}
		System.out.printf("%-100.100s%n", "------------------------------------------------------------------\n");
		
	}
	
	
	
}
