package project.hospital;

public class Driver1 {
	
	public static void main(String[] args) 
	{
		//Initialize the Hospital
		
		
		
		
		
		
	}

}
