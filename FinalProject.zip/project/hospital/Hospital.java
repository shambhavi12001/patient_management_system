package project.hospital;

import java.util.ArrayList;

import project.people.Admin;

public class Hospital {
	
	//Fields
	private ArrayList<Department> departmentList;
	private ArrayList<Admin> adminList;
	
	//Constructor
	public Hospital() {
		this.departmentList = new ArrayList<Department>();
		this.setAdminList(new ArrayList<Admin>());
	}

	//Getters and Setters
	public ArrayList<Department> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(ArrayList<Department> departmentList) {
		this.departmentList = departmentList;
	}

	public ArrayList<Admin> getAdminList() {
		return adminList;
	}

	public void setAdminList(ArrayList<Admin> adminList) {
		this.adminList = adminList;
	}
	
	//Methods
	
}
