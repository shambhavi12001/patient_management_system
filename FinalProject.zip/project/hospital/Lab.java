package project.hospital;

public class Lab {
	
	//Fields
	private String name;
	
	//Constructor
	public Lab() {
		this.name = "unknown";
	}
	
	//Getters and Setters
	public String getName() {
		return this.name;
	}
	public void setName(String s) {
		this.name = s;
	}
	
	//Methods
}
