package project.hospital;

import java.util.ArrayList;

import project.people.Doctor;

public class Department {
	
	//Fields
	private String name;
	private ArrayList<Doctor> doctorList;
	
	//Constructor
	public Department() {
		this.name = "unknown";
		this.setDoctorList(new ArrayList<Doctor>());
	}
	
	//Getters and Setters
	public String getName() {
		return this.name;
	}
	public void setName(String s) {
		this.name = s;
	}

	public ArrayList<Doctor> getDoctorList() {
		return doctorList;
	}

	public void setDoctorList(ArrayList<Doctor> doctorList) {
		this.doctorList = doctorList;
	}
	
	//Methods
}
