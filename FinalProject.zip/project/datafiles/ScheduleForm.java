package project.datafiles;

import project.people.InPatient;
import project.people.OutPatient;

public class ScheduleForm {

	//Fields
	private OutPatient patient;	
	
	//Constructor
	public ScheduleForm() {
		this.setPatient(null);		
	}

	//Getters and Setters
	public OutPatient getPatient() {
		return patient;
	}

	public void setPatient(OutPatient patient) {
		this.patient = patient;
	}
	
	//Methods
}