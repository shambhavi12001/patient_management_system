package project.datafiles;

public class Insurance {
	
	//Fields
	private String name;
	private double deductible;
	private double coverRate;
	
	//Constructor
	public Insurance() {
		this.name = "unknown";
		this.deductible = 0.00;
		this.coverRate = 0.00;
	}
	
	//Getters and Setters
	public String getName() {
		return this.name;
	}
	public void setName(String s) {
		this.name = s;
	}
	
	public double getDeductible() {
		return this.deductible;
	}
	public void setDeductible(double d) {
		this.deductible = d;
	}
	
	public double getCoverRate() {
		return this.coverRate;
	}
	public void setCoverRate(double d) {
		this.coverRate = d;
	}
	
	//Methods
	public double getPretotal(double d) {
		if(d > this.deductible) {
			d = d - this.deductible;
			d = d * (100.0 - this.coverRate);
			d = d / 100;
			return d + this.deductible;
		}
		else {
			return this.deductible;
		}
	}
}

