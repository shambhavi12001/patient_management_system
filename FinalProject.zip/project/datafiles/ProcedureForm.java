package project.datafiles;

import project.people.InPatient;

public class ProcedureForm {
	
	//Fields
	private InPatient patient;	
	
	//Constructor
	public ProcedureForm() {
		this.setPatient(null);		
	}

	//Getters and Setters
	public InPatient getPatient() {
		return patient;
	}

	public void setPatient(InPatient patient) {
		this.patient = patient;
	}
	

	//Methods
	
}
