package project.datafiles;

public class LabReport {
	
	//Fields
	private String results;
	
	//Constructor
	public LabReport() {
		this.results = "unknown";
	}
	
	//Getters and Setters
	public String getResults() {
		return this.results;
	}
	public void setResults(String s) {
		this.results = s;
	}
	
	//Methods
	public void print();

}
