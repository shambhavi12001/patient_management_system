package project.datafiles;

import java.util.ArrayList;

public class Schedule {
	
	//Fields
	private ArrayList<Appointment> appointmentList;
	
	//Constructor
	public Schedule() {
		
	}
	
	//Getters and Setters
	public ArrayList<Appointment> getAppointmentList() {
		return appointmentList;
	}

	public void setAppointmentList(ArrayList<Appointment> appointmentList) {
		this.appointmentList = appointmentList;
	}


	//Methods
	public void sort();
	public void addAppointment();
	public void print();
	

}
