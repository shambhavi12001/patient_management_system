package project.datafiles;

import project.people.Doctor;
import project.people.OutPatient;

public class Appointment {
	
	//Fields
	private int date;
	private int time;
	private Doctor doctor;
	private OutPatient patient;
	private String comments;
	
	//Constructor
	public Appointment() {
		this.date = 0;
		this.time = 0;
		this.comments = "unknown";
	}
	
	//Getters and Setters
	public int getDate() {
		return this.date;
	}
	public void setDate(int i) {
		this.date = i;
	}
	public int getTime() {
		return this.time;
	}
	public void setTime(int i) {
		this.time = i;
	}
	
	public String getComments() {
		return this.comments;
	}
	public void setComments(String s) {
		this.comments = s;
	}
	
	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public OutPatient getPatient() {
		return patient;
	}

	public void setPatient(OutPatient patient) {
		this.patient = patient;
	}

	//Methods
	public void printAppoinment();
}
