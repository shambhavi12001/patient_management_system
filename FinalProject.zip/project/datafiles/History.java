package project.datafiles;

public class History {
	
	//Fields
	private String family;
	private String vaccination;
	private String patient;
	
	//Constructor
	public History() {
		this.family = "unknown";
		this.vaccination = "unknown";
		this.patient = "unknown";
	}
	
	//Getters and Setters
	public String getPatient() {
		return this.patient;
	}
	public void setPatient(String s) {
		this.patient = s;
	}
	
	public String getFamily() {
		return this.family;
	}
	public void setFamily(String s) {
		this.family = s;
	}
	
	public String getVaccination() {
		return this.vaccination;
	}
	public void setVaccination(String s) {
		this.vaccination = s;
	}
	//Methods
	public void print();
	
}
