package project.datafiles;

public class Billing {
	
	//Fields
	private Insurance insurance;
	private double pharmacy;
	private double procedure;
	private double stay;
	private double pretotal;
	private double total;
	private double taxRate;

	//Constructor
	public Billing() {
		this.pharmacy = 0.00;
		this.procedure = 0.00;
		this.stay = 0.00;
		this.pretotal = 0.00;
		this.total = 0.00;
		this.taxRate = 0.00;
	}
	
	//Getters and Setters
	public double getPharmacy() {
		return this.pharmacy;
	}
	public void setPharmacy(double d) {
		this.pharmacy = d;
	}

	public double getProcedure() {
		return this.procedure;
	}
	public void setProcedure(double d) {
		this.procedure = d;
	}
	
	public double getStay() {
		return this.stay;
	}
	public void setStay(double d) {
		this.stay = d;
	}
	
	public double getPretotal() {
		return this.pretotal;
	}
	public void setPretotal(double d) {
		this.pretotal = d;
	}
	
	public double getTaxRate() {
		return this.taxRate;
	}
	public void setTaxRate(double d) {
		this.taxRate = d;
	}
	
	public double getTotal() {
		return this.total;
	}
	public void setTotal(double d) {
		this.total = d;
	}

	public Insurance getInsurance() {
		return insurance;
	}

	public void setInsurance(Insurance insurance) {
		this.insurance = insurance;
	}
	
	//Methods
	public void update() {
		this.pretotal = this.pharmacy + this.stay + this.procedure;
		this.pretotal = this.insurance.getPretotal(this.pretotal);
		this.total = this.pretotal * (100 + this.taxRate);
		this.total = this.total / 100;
	}
	public void print();
}
