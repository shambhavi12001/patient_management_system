package project.datafiles;

import java.util.ArrayList;

public class Chart {
	
	//Fields
	private String comments;
	private ArrayList<LabReport> listOfLabs;
	
	//Constructor
	public Chart() {
		this.setComments("unknown");
		this.setListOfLabs(new ArrayList<LabReport>());
		
	}
	
	//Getters and Setters
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public ArrayList<LabReport> getListOfLabs() {
		return listOfLabs;
	}

	public void setListOfLabs(ArrayList<LabReport> listOfLabs) {
		this.listOfLabs = listOfLabs;
	}
		
	//Methods
	public void print();
	
}
