package project.datafiles;

import project.people.Doctor;

public class Form {
	
	//Fields
	private Doctor doctor;
	//Constructor
	public Form() {
		this.setDoctor(null);		
	}

	//Getters and Setters
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	
	//Methods

}
