package project.people;

import project.datafiles.Schedule;
import project.hospital.Department;

public class Doctor	extends Staff {

	//Fields
	Department department;
	Schedule schedule;
	//Constructor
	public Doctor() {
		this.department = null;
		this.schedule = null;
	}
	
	//Getters and Setters
	public Department getDepartment() {
		return this.department;
	}
	public void setDepartment(Department  dept) {
		this.department = dept;
	}
	
	public Schedule getSchedule() {
		return this.schedule;
	}
	public void setSchedule(Schedule sched) {
		this.schedule = sched;
	}
	//Methods
	
	public void requesteProcedure();
	public void admit();
	public void discharge();
}
