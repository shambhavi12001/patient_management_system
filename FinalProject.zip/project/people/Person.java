package project.people;

public class Person {
	
	//Fields
	private int DOB;
	private String name;
	private String address;
	
	//Constructor
	Person() {
		this.DOB = 0;
		this.name = "unknown";
		this.address = "unknown";
		
	}
	
	//Getters and Setters
	public int getDOB() {
		return this.DOB;
	}
	public void setDOB(int i) {
		this.DOB = i;
	}
	
	public String getName() {
		return this.name;
	}
	public void setName(String s) {
		this.name = s;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	//Methods

}
