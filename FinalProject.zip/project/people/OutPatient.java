package project.people;

import project.datafiles.Schedule;
import project.datafiles.ScheduleForm;

public class OutPatient extends Patient {
	
	//Fields
	private Schedule schedule;
	private ScheduleForm scheduleForm;

	//Constructor
	public OutPatient() {
		this.schedule = null;
		this.setScheduleForm(null);
	}
	
	//Getters and Setters
	public Schedule getSchedule() {
		return this.schedule;
	}
	public void setSchedule(Schedule sched) {
		this.schedule = sched;
	}

	public ScheduleForm getScheduleForm() {
		return scheduleForm;
	}

	public void setScheduleForm(ScheduleForm scheduleForm) {
		this.scheduleForm = scheduleForm;
	}
	
	//Methods
	public void addScheduleForm();
	
	

}
