package project.people;

import java.util.ArrayList;

import project.datafiles.ProcedureForm;
import project.datafiles.ScheduleForm;

public class Admin extends Staff{
	
	//Fields
	private ArrayList<ScheduleForm> listOfScheduleForms;
	private ArrayList<ProcedureForm> listOfProcedureForms;
	//Constructor
	public Admin() {
		this.setListOfProcedureForms(new ArrayList<ProcedureForm>());
		this.setListOfScheduleForms(new ArrayList<ScheduleForm>());
	}
	
	//Getters and Setters
	public ArrayList<ScheduleForm> getListOfScheduleForms() {
		return listOfScheduleForms;
	}
	public void setListOfScheduleForms(ArrayList<ScheduleForm> listOfScheduleForms) {
		this.listOfScheduleForms = listOfScheduleForms;
	}

	public ArrayList<ProcedureForm> getListOfProcedureForms() {
		return listOfProcedureForms;
	}

	public void setListOfProcedureForms(ArrayList<ProcedureForm> listOfProcedureForms) {
		this.listOfProcedureForms = listOfProcedureForms;
	}
	

	//Methods
	public void addProcedureForm();
	public void removeProcedureForm();
	public void addScheduleForm();
	public void removeScheduleForm();
	public void approveProcedure();
	public void approveSchedule();


}
