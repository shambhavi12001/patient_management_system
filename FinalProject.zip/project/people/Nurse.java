package project.people;

import java.util.ArrayList;

public class Nurse extends Staff{
	
	//Fields
	private ArrayList<InPatient> listOfPatients;
	
	//Constructor
	public Nurse() {
		this.listOfPatients = new ArrayList<InPatient>();
	}
	
	//Getters and Setters
	public ArrayList<InPatient> getListOfPatients() {
		return this.listOfPatients;
	}
	
 	//Methods
	public void addInPatient(InPatient e) {
		this.listOfPatients.add(e);
	}
	
	public void removePatient(InPatient e) {
		if(this.listOfPatients.contains(e)) {
			this.listOfPatients.remove(e);
		}
		else {
			System.out.println("Error");
		}
	}
	
	public void requestScheduleChange(OutPatient p) {
		//TODO
	}
}
