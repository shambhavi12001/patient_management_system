package project.people;

import project.datafiles.ProcedureForm;
import project.hospital.Room;

public class InPatient extends Patient{

	//Fields
	private Doctor doctor;
	private Nurse nurse;
	private Room room;
	private ProcedureForm procedureForm;

	//Constructor
	public InPatient() {
		this.nurse = null;
		this.doctor = null;
		this.setRoom(null);
		this.setProcedureForm(null);
	}
	
	//Getters and Setters
	public Nurse getNurse() {
		return this.nurse;
	}
	public void setNurse(Nurse n) {
		this.nurse = n;
	}
	
	public Doctor getDoctor() {
		return this.doctor;
	}
	public void setDoctor(Doctor n) {
		this.doctor = n;
	}
	
	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public ProcedureForm getProcedureForm() {
		return procedureForm;
	}

	public void setProcedureForm(ProcedureForm procedureForm) {
		this.procedureForm = procedureForm;
	}
	
	//Methods
	public void addProcedureForm();
}
