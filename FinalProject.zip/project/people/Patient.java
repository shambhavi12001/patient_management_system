package project.people;

import project.datafiles.Billing;
import project.datafiles.Chart;
import project.datafiles.History;

public class Patient extends Person{
	
	//Fields
	private Chart chart;
	private Billing billing;
	private History history;
	
	//Constructor
	public Patient() {
		this.chart = null;
		this.billing = null;
		this.history = null;
	}
	//Getters and Setters
	public Chart getChart() {
		return this.chart;
	}
	public void setChart(Chart c) {
		this.chart = c;
	}
	
	public Billing getBilling() {
		return this.billing;
	}
	public void setBilling(Billing v) {
		this.billing = v;
	}
	//Methods
	public History getHistory() {
		return history;
	}
	public void setHistory(History history) {
		this.history = history;
	}
}
